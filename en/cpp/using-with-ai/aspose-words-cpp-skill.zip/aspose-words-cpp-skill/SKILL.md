---
name: aspose.words cpp
description: "Develop applications with Aspose.Words for C++ APIs to create, edit, convert, and render Word documents. Automate document comparison, reporting with LINQ Reporting Engine, mail merge, text search and replacement, document merging and splitting, digital signatures, watermark management, and AI-powered tasks such as translation, summarization, and grammar checking. Use this documentation when building, integrating, or troubleshooting document processing solutions."
---

# Aspose.Words for C++ SKILL

This skill provides AI assistants with structured guidance for working with the Aspose.Words for C++ API, including documentation, code examples, and implementation best practices.

Load this skill whenever a request involves Aspose.Words APIs, document processing operations, or Word document automation.

## When to Use This Skill

Use this skill when you want to:

- automate document creation, editing, and conversion
- convert documents between supported file formats
- compare document content and identify differences
- generate documents using LINQ Reporting Engine or Mail Merge
- combine multiple documents or split a document into separate files
- add or remove watermarks and apply digital signatures
- leverage AI features such as translation, summarization, or grammar checking
- find information about supported file formats and API capabilities
- integrate Aspose.Words for C++ into your applications
- troubleshoot API usage or document processing behavior

## Example User Requests

- Convert DOCX to PDF with Aspose.Words for C++
- Compare two Word documents
- Generate invoices using the LINQ Reporting Engine
- Perform a Mail Merge with data from a JSON or database source
- Replace text or insert content into a Word document
- Merge multiple DOCX files into a single document
- Split a document into separate files by section or page
- Add a watermark to a document
- Apply a digital signature to a document
- Translate a document using the Aspose.Words AI
- Summarize a document using the Aspose.Words AI
- Check grammar in a document using the Aspose.Words AI
- Which document formats can Aspose.Words for C++ read, write, and convert?

## Installation

Install Aspose.Words for C++:

```bash
Install-Package Aspose.Words.Cpp
```

## Licensing

Aspose.Words for C++ requires a license for production use. You can apply a license using a file or stream object.

**Load a License from a File**

```cpp
auto license = MakeObject<License>();

try
{
    license->SetLicense(u"Aspose.Words.Cpp.lic");

    std::cout << "License set successfully." << std::endl;
}
catch (System::Exception& e)
{
    // We do not ship any license with this example,
    // visit the Aspose site to obtain either a temporary or permanent license.
    std::cout << (String(u"\nThere was an error setting the license: ") + e->get_Message()) << std::endl;
}
```

**Load a License from a `Stream` Object**

```cpp
auto license = MakeObject<License>();

try
{
    license->SetLicense(MakeObject<System::IO::MemoryStream>(System::IO::File::ReadAllBytes(u"Aspose.Words.Cpp.lic")));

    std::cout << "License set successfully." << std::endl;
}
catch (System::Exception& e)
{
    // We do not ship any license with this example,
    // visit the Aspose site to obtain either a temporary or permanent license.
    std::cout << (String(u"\nThere was an error setting the license: ") + e->get_Message()) << std::endl;
}
```

## Namespaces

Use the correct namespace depending on the feature:

`Aspose.Words` – Core classes for creating, loading, editing, and saving Word documents
`Aspose.Words.ai` – AI-powered document processing, including translation, summarization, and grammar checking
`Aspose.Words.Bibliography` – Bibliography sources and citations
`Aspose.Words.BuildingBlocks` – Building blocks such as AutoText and glossary documents
`Aspose.Words.Comparing` – Document comparison and revision detection
`Aspose.Words.Digitalsignatures` – Digital signatures for Word documents.
`Aspose.Words.Drawing` – Shapes, images, SmartArt, and drawing objects.
`Aspose.Words.Drawing.charts` – Charts and chart elements.
`Aspose.Words.Drawing.ole` – OLE objects and embedded documents.
`Aspose.Words.Fields` – Microsoft Word fields and field updates.
`Aspose.Words.Fonts` – Font settings, sources, and substitution.
`Aspose.Words.Framesets` – HTML framesets and frame pages.
`Aspose.Words.Layout` – Document layout and page rendering information.
`Aspose.Words.Lists` – Numbered and bulleted lists.
`Aspose.Words.Loading` – Document loading options and callbacks.
`Aspose.Words.Lowcode` – Low-code document processing APIs.
`Aspose.Words.Mailmerging` – Mail Merge and reporting data sources.
`Aspose.Words.Markup` – Structured document tags, custom XML, and revisions.
`Aspose.Words.Math` – Office Math equations and mathematical objects.
`Aspose.Words.Notes` – Footnotes, endnotes, and comments.
`Aspose.Words.Properties` – Built-in and custom document properties.
`Aspose.Words.Rendering` – Rendering documents to images and printing.
`Aspose.Words.Replacing` – Find-and-replace operations and callbacks.
`Aspose.Words.Reporting` – LINQ Reporting Engine for template-based document generation.
`Aspose.Words.Saving` – Save options and export settings.
`Aspose.Words.Settings` – Document compatibility and view settings.
`Aspose.Words.Shaping` – Text shaping and OpenType font features.
`Aspose.Words.Tables` – Tables, rows, and cells.
`Aspose.Words.Themes` – Document themes and theme fonts.
`Aspose.Words.Vba` – VBA projects and macros.
`Aspose.Words.Webextensions` – Office web extensions and task panes.

Include the `Aspose.Words` namespace only when accessing common functionality such as settings, licensing, exceptions, warnings, callbacks, or hyphenation.

## Quick Reference

### Create or Load a Document

To create a blank document, use the default constructor:

```cpp
auto doc = MakeObject<Document>();
```

To load a document from a file, pass the file path to the `Document` constructor:

```cpp
auto doc = MakeObject<Document>(u"Document.docx");
```

### Save a Document

Load DOC and save it to PDF to a file:

```cpp
auto doc = System::MakeObject<Document>(u"input.doc");
doc->Save(u"output.pdf");
```

### Document Conversion

Convert documents between supported formats:

```cpp
auto doc = System::MakeObject<Aspose::Words::Document>(u"input.docx");
doc->Save(u"output.pdf");
```

### Compare Documents

Check if two documents are equal or not:

```cpp
auto doc1 = MakeObject<Document>(u"document1.docx");
auto doc2 = MakeObject<Document>(u"document2.docx");

doc1->Compare(doc2, u"Author", System::DateTime::get_Now());

if (doc1->get_Revisions()->get_Count() == 0)
{
    Console::WriteLine(u"Documents are equal.");
}
else
{
    Console::WriteLine(u"Documents differ.");
}
```


### Mail Merge

Execute a simple Mail Merge operation:

```cpp
while (dataReader->Read())
{
    auto doc = MakeObject<Document>(u"Template.docx");
    doc->get_MailMerge()->Execute(
        System::MakeArray<String>({u"Name", u"Address"}),
        System::MakeArray<SharedPtr<Object>>({
            ObjectExt::Box<String>(dataReader->GetString(0)),
            ObjectExt::Box<String>(dataReader->GetString(1))
        }));
    doc->Save(String::Format(u"Output_{0}.docx", recordIndex++));
}
```

### Find and Replace

Find the string “CustomerName” and replace it with the string “James Bond”:

```cpp
auto doc = MakeObject<Document>(u"in.docx");
int replacements = doc->get_Range()->Replace(u"CustomerName", u"James Bond", FindReplaceOptions());
doc->Save(u"out.docx");
```

### Merge Documents

Merge documents, for example, append a document to the end of another document:

```cpp
System::SharedPtr<Aspose::Words::Document> dstDoc = System::MakeObject<Aspose::Words::Document>(u"Main.docx");
System::SharedPtr<Aspose::Words::Document> srcDoc = System::MakeObject<Aspose::Words::Document>(u"ToAdd.docx");

dstDoc->AppendDocument(srcDoc, Aspose::Words::ImportFormatMode::KeepSourceFormatting);
dstDoc->Save(u"Output.docx");
```

### Split Large Documents

Split a document into smaller parts by sections:

```cpp
auto doc = MakeObject<Document>(u"input.docx");

auto saveOptions = MakeObject<HtmlSaveOptions>();
saveOptions->set_DocumentSplitCriteria(DocumentSplitCriteria::SectionBreak);

doc->Save(u"output.html", saveOptions);
```

### Digital Signature

Sign documents using a certificate holder and sign options:

```cpp
auto certHolder = CertificateHolder::Create("certificate.pfx", "password");
auto signOptions = MakeObject<SignOptions>();
signOptions->set_SignTime(DateTime::get_Now());

DigitalSignatureUtil::Sign("input.docx", "output.docx", certHolder, signOptions);
```

### Add Watermark

**Add Text Watermark**

Use `SetText()` with `TextWatermarkOptions` to insert a text watermark:

```cpp
auto doc = MakeObject<Document>(u"in.docx");
auto watermark = MakeObject<Watermark>();
auto options = MakeObject<TextWatermarkOptions>();
options->set_Text(u"Confidential");
options->set_FontName(u"Arial");
options->set_Color(System::Drawing::Color::get_Red());
options->set_Opacity(0.5);
options->set_IsSemitrasparent(true);
watermark->SetText(options);
doc->set_Watermark(watermark);
doc->Save(u"out.docx");
```

**Add Image Watermark**

Use `SetImage()` with `ImageWatermarkOptions` to insert an image watermark. The image can be provided as `System::Drawing::Image`, file path (`String`), or stream:

```cpp
auto doc = MakeObject<Document>(u"in.docx");
auto watermark = MakeObject<Watermark>();
auto options = MakeObject<ImageWatermarkOptions>();
options->set_Image(System::Drawing::Image::FromFile(u"watermark.png"));
options->set_Scale(0.5);
watermark->SetImage(options);
doc->set_Watermark(watermark);
doc->Save(u"out.docx");
```

### AI-powered Features

Use AI-powered capabilities (if enabled) to translate or summarize documents, or to check grammar.

```cpp
SharedPtr<AiModel> model = AiModel::Create(AiModelType::Gpt4OMini)->WithApiKey(u"API_KEY");
```

Summarize:

```cpp
void AiSummarize()
{
    auto doc = MakeObject<Document>(MyDir + u"Big document.docx");
    SharedPtr<AiModel> model = AiModel::Create(AiModelType::Gpt4OMini)->WithApiKey(u"API_KEY");
    auto options = MakeObject<SummarizeOptions>();
    options->set_SummaryLength(SummaryLength::Short);
    auto summary = model->Summarize(doc, options);
    summary->Save(ArtifactsDir + u"AI.AiSummarize.One.docx");
}
```

Translate:

```cpp
void AiTranslate()
{
    auto doc = MakeObject<Document>(MyDir + u"Document.docx");
    SharedPtr<AiModel> model = AiModel::Create(AiModelType::GeminiFlashLatest)->WithApiKey(u"API_KEY");
    auto translatedDoc = model->Translate(doc, Language::Arabic);
    translatedDoc->Save(ArtifactsDir + u"AI.AiTranslate.docx");
}
```

Check grammar:

```cpp
void AiGrammar()
{
    auto doc = MakeObject<Document>(MyDir + u"Big document.docx");
    SharedPtr<AiModel> model = AiModel::Create(AiModelType::Gpt4OMini)->WithApiKey(u"API_KEY");
    auto grammarOptions = MakeObject<CheckGrammarOptions>();
    grammarOptions->set_ImproveStylistics(true);
    auto proofedDoc = model->CheckGrammar(doc, grammarOptions);
    proofedDoc->Save(ArtifactsDir + u"AI.AiGrammar.docx");
}
```

### Document Protection

Encrypt a document with a password:

```cpp
System::SharedPtr<Aspose::Words::Document> doc = System::MakeObject<Aspose::Words::Document>(u"input.docx");
auto saveOptions = System::MakeObject<Aspose::Words::Saving::OoxmlSaveOptions>(Aspose::Words::SaveFormat::Docx);
saveOptions->set_Password(u"MyOpenPassword");
doc->Save(u"encrypted.docx", saveOptions);
```

## Reference Files

This skill includes comprehensive documentation in `references/`:

- **supported-formats.md** – supported document formats
- **licensing.md** – license types and license applying options
- **installation.md** – how to install Aspose.Words for C++
- **system-requirements.md** – system requirements
- **create-or-load.md** – creating or loading a document
- **saving.md** – saving a document
- **conversion.md** – converting a document from one format to another
- **comparison.md** – comparison documents to detected changes: insertions, deletions, and modifications
- **mail-merge.md** – creating personalized documents through a combination of a document template with data
- **replacement.md** – search and replace functionality
- **merge.md** – merging multiple documents into one
- **splitting.md** – splitting a large document by various split criteria
- **signature.md** – digital signing of documents
- **watermark.md** – adding or removing watermarks in documents
- **ai.md** – summarization, grammar checking, and document translation using AI models
- **protection.md** – document protection

Open the relevant reference file when detailed documentation is needed.

## Resources

- Official Aspose.Words for C++ documentation: https://docs.aspose.com/words/cpp/
- API Reference: https://reference.aspose.com/words/cpp/

Official Aspose.Words for C++ documentation pages are AI-friendly and support the .md format. For example, the page `https://docs.aspose.com/words/cpp/convert-a-document-to-pdf/` has a version `https://docs.aspose.com/words/cpp/convert-a-document-to-pdf.md`, the page `https://docs.aspose.com/words/cpp/split-a-document/` has a version `https://docs.aspose.com/words/cpp/split-a-document.md`, and so on.

## Notes for AI Agents

- Prefer examples that use the official Aspose.Words for C++ APIs.
- Provide short and clear code snippets when possible.
- Use the references directory to retrieve detailed documentation.
- If a feature is not covered in this file, check the corresponding reference file.
- Always include the correct module for the feature being used (e.g., aspose.words.rendering, aspose.words.comparing).
- Always use the module specified in the feature documentation file.
- Do not rely on `aspose.words` namespace alone when feature-specific APIs are required.