# Aspose.Words for C++ - Document Protection and Encryption

---
**URL:** https://docs.aspose.com/words/cpp/protect-or-encrypt-a-document.md

**Contents:**
- Document Protection Overview
- Read-Only Protection
- Password-Based Encryption
- Restrict Editing
- Digital Signatures
---

title: "Protect or Encrypt a Document in C++"
---

**Document Protection Overview**

Aspose.Words for C++ supports multiple document protection and encryption features equivalent to Microsoft Word capabilities. These include read-only protection, password-based encryption, editing restrictions, and digital signatures. Protection helps prevent unauthorized modification, copying, or data leakage.

Note: Aspose.Words does **not** support Microsoft Word features “Mark as Final” and “Restrict Access”.

Supported protection types:

| Aspose.Words feature | Description |
|----------------------|-------------|
| Read-Only | Recommends opening the document as read-only; optionally protected with a password to modify. |
| Encrypt a Document | Applies encryption to the file so it requires a password to open. |
| Restrict Editing | Limits editing to specific actions (e.g., comments, revisions, form fields). |
| Digital Signatures | Adds or verifies cryptographic signatures for authenticity and integrity. |

**Read-Only Protection**

Use `WriteProtection` to recommend read-only mode or require a password to modify the document. This does **not** encrypt the file.

```cpp
System::SharedPtr<Aspose::Words::Document> doc = System::MakeObject<Aspose::Words::Document>(u"input.docx");
doc->get_WriteProtection()->set_ReadOnlyRecommended(true);
doc->get_WriteProtection()->SetPassword(u"yourPassword");
doc->Save(u"readonly.docx");
```

Check if write protection is applied:

```cpp
bool isProtected = doc->get_WriteProtection()->get_IsWriteProtected();
```

Remove read-only recommendation:

```cpp
doc->get_WriteProtection()->set_ReadOnlyRecommended(false);
doc->Save(u"editable.docx");
```

Note: The password is stored as a document property and can be removed by editing document metadata; it is not strong security.

**Password-Based Encryption**

Encryption transforms document content into unreadable bytes using a password. Only users with the correct password can open the document.

Use format-specific save options to set the password:

```cpp
System::SharedPtr<Aspose::Words::Document> doc = System::MakeObject<Aspose::Words::Document>(u"input.docx");
auto saveOptions = System::MakeObject<Aspose::Words::Saving::OoxmlSaveOptions>(Aspose::Words::SaveFormat::Docx);
saveOptions->set_Password(u"MyOpenPassword");
doc->Save(u"encrypted.docx", saveOptions);
```

Supported formats and encryption algorithms:

| Format | Encryption while Saving |
|--------|-------------------------|
| DOC, DOT | RC4 (40-bit) |
| DOCX, DOTX, DOCM, DOTM, FlatOPC | ECMA-376 Standard (AES128 + SHA1) |
| ODT, OTT | ODF Encryption (AES256 + SHA256) |
| PDF | AES-128 / AES-256 (based on PDF version) |

Detect if a document is encrypted before loading:

```cpp
auto info = Aspose::Words::FileFormatUtil::DetectFileFormat(u"input.docx");
bool isEncrypted = info->get_IsEncrypted();
```

Load an encrypted document with a password:

```cpp
System::SharedPtr<Aspose::Words::LoadOptions> loadOptions = System::MakeObject<Aspose::Words::LoadOptions>();
loadOptions->set_Password(u"MyOpenPassword");
System::SharedPtr<Aspose::Words::Document> doc = System::MakeObject<Aspose::Words::Document>(u"encrypted.docx", loadOptions);
```

Note: Attempting to load an encrypted document without a password throws `IncorrectPasswordException`.

**Restrict Editing**

Use `Document::Protect()` to restrict editing to specific actions. This does **not** encrypt the document.

Supported `ProtectionType` values:

- `ReadOnly`: Entire document is non-editable.
- `AllowOnlyComments`: Only comments can be added.
- `AllowOnlyRevisions`: Only tracked changes allowed.
- `AllowOnlyFormFields`: Only form fields can be edited.
- `NoProtection`: No restrictions (default).

Example with password:

```cpp
System::SharedPtr<Aspose::Words::Document> doc = System::MakeObject<Aspose::Words::Document>(u"input.docx");
doc->Protect(Aspose::Words::ProtectionType::AllowOnlyComments, u"commentPassword");
doc->Save(u"protected.docx");
```

Remove protection (with or without password):

```cpp
doc->Unprotect(); // removes protection regardless of password
// or
bool success = doc->Unprotect(u"commentPassword"); // returns false if password incorrect
```

Define editable regions inside a protected document:

```cpp
System::SharedPtr<Aspose::Words::DocumentBuilder> builder = System::MakeObject<Aspose::Words::DocumentBuilder>(doc);
auto rangeStart = builder->StartEditableRange();
builder->Writeln(u"This part can be edited.");
builder->EndEditableRange(rangeStart);
```

**Digital Signatures**

Use `DigitalSignatureUtil` to sign, verify, count, and remove digital signatures.

Detect if a document contains signatures:

```cpp
auto info = Aspose::Words::FileFormatUtil::DetectFileFormat(u"input.docx");
bool hasSignature = info->get_HasDigitalSignature();
```

Verify signatures:

```cpp
auto signatures = Aspose::Words::DigitalSignatures::DigitalSignatureUtil::LoadSignatures(u"signed.docx");
bool isValid = signatures->get_IsValid();
```

Sign a document:

```cpp
auto certHolder = Aspose::Words::DigitalSignatures::CertificateHolder::Create(u"cert.pfx", u"certPassword");
Aspose::Words::DigitalSignatures::DigitalSignatureUtil::Sign(u"input.docx", u"signed.docx", certHolder);
```

Retrieve signature value:

```cpp
auto signatures = Aspose::Words::DigitalSignatures::DigitalSignatureUtil::LoadSignatures(u"signed.docx");
System::ArrayPtr<uint8_t> sigValue = signatures->idx_get(0)->get_SignatureValue();
```

Remove all signatures:

```cpp
Aspose::Words::DigitalSignatures::DigitalSignatureUtil::RemoveAllSignatures(u"input.docx", u"unsigned.docx");
```

Note: Digital signatures are lost when loading and saving a document. Re-sign after processing if needed.
