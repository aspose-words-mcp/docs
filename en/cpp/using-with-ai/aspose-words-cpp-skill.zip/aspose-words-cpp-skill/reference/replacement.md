# Aspose.Words for C++ – Find and Replace
---
**URL:** https://docs.aspose.com/words/cpp/find-and-replace.md

**Contents:**
- Ways to Find and Replace
- Find and Replace Text Using Simple String Replacement
- Find and Replace Text Using Regular Expressions
- Find and Replace String Using Metacharacters
- Find and Replace String in Header/Footer of a Document
- Ignore Text During Find and Replace

---
title: "Find and Replace in C++"
---

**Ways to Find and Replace**

Aspose.Words for C++ supports two primary approaches for find and replace operations:

1. **Simple string replacement** – replaces all occurrences of a specified string with another. Matching can be case-sensitive or case-insensitive, and can be restricted to whole words only.
2. **Regular expression replacement** – uses regex patterns to match complex text sequences. Words are defined as sequences of alphanumeric characters only.

Both approaches are provided via the `Aspose::Words::Replacing` namespace and support customization through the `FindReplaceOptions` class.

**Find and Replace Text Using Simple String Replacement**

Use the `Range::Replace` method with string arguments:

```cpp
auto doc = MakeObject<Document>(u"in.docx");
int replacements = doc->get_Range()->Replace(u"CustomerName", u"James Bond", FindReplaceOptions());
doc->Save(u"out.docx");
```

Options include:
- `FindReplaceOptions::set_CaseSensitive(bool)`
- `FindReplaceOptions::set_MatchWholeWord(bool)`

**Find and Replace Text Using Regular Expressions**

Use the `Range::Replace` overload accepting a `Regex` object:

```cpp
auto doc = MakeObject<Document>(u"in.docx");
auto regex = MakeObject<System::Text::RegularExpressions::Regex>(u"([a-zA-Z]+) \\1");
int replacements = doc->get_Range()->Replace(regex, u"$1", FindReplaceOptions());
doc->Save(u"out.docx");
```

This example replaces duplicate consecutive words (e.g., "the the") with a single occurrence.

**Find and Replace String Using Metacharacters**

Metacharacters in search or replacement strings represent document structure:

- `&p` – paragraph break  
- `&b` – section break  
- `&m` – page break  
- `&l` – line break  
- `&&` – literal `&`

Example: replace text with a paragraph break:

```cpp
auto doc = MakeObject<Document>(u"in.docx");
doc->get_Range()->Replace(u"TextToReplace", u"ReplacementText&p", FindReplaceOptions());
doc->Save(u"out.docx");
```

**Find and Replace String in Header/Footer of a Document**

Access headers/footers via `HeaderFooter` objects and perform replacement on their `Range`:

```cpp
auto doc = MakeObject<Document>(u"in.docx");
auto section = doc->get_FirstSection();
auto headersFooters = section->get_HeadersFooters();

auto header = headersFooters->idx_get(HeaderFooterType::HeaderPrimary);
header->get_Range()->Replace(u"Aspose.Words", u"Remove", FindReplaceOptions());

auto footer = headersFooters->idx_get(HeaderFooterType::FooterPrimary);
footer->get_Range()->Replace(u"(C) 2006 Aspose Pty Ltd.", u"Copyright (C) Aspose Pty Ltd.", FindReplaceOptions());

doc->Save(u"out.docx");
```

**Ignore Text During Find and Replace**

Use `FindReplaceOptions` to exclude specific document elements:

- `set_IgnoreDeleted(bool)` – ignore deleted revisions  
- `set_IgnoreInserted(bool)` – ignore inserted revisions  
- `set_IgnoreFields(bool)` – ignore field codes and results  
- `set_IgnoreFieldCodes(bool)` – ignore field codes only  
- `set_IgnoreFootnotes(bool)` – ignore footnotes and endnotes  

Example: ignore deleted text:

```cpp
auto doc = MakeObject<Document>(u"in.docx");
auto options = MakeObject<FindReplaceOptions>();
options->set_IgnoreDeleted(true);
doc->get_Range()->Replace(u"old", u"new", options);
doc->Save(u"out.docx");
```

**Customize Find and Replace Operation**

Use `FindReplaceOptions` properties for advanced control:

- `set_ApplyFont(const SharedPtr<Font>&)` – apply font formatting to replacement  
- `set_ApplyParagraphFormat(const SharedPtr<ParagraphFormat>&)` – apply paragraph formatting  
- `set_UseSubstitutions(bool)` – enable regex substitutions (`$1`, `$&`, etc.)  
- `set_ReplacingCallback(SharedPtr<IReplacingCallback>)` – inject custom logic during replacement  

Example: highlight matched text:

```cpp
auto doc = MakeObject<Document>(u"in.docx");
auto options = MakeObject<FindReplaceOptions>();
options->set_ApplyFont(MakeObject<Font>());
options->get_ApplyFont()->set_HighlightColor(System::Drawing::Color::get_Yellow());
doc->get_Range()->Replace(u"important", u"important", options);
doc->Save(u"out.docx");
```

---