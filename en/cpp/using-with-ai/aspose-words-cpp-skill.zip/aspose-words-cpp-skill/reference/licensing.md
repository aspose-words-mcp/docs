# Aspose.Words for C++ - Licensing and Subscription

---
**URL:** https://docs.aspose.com/words/cpp/licensing.md

**Contents:**
- Free Trial or Temporary License
- Purchased License
- License Applying Options
- Changing the License File Name
- “Cannot find license filename” Exception
- Using Multiple Aspose Products

---
title: "Licensing and Subscription"
---

**Free Trial or Temporary License**

The evaluation version of Aspose.Words for C++ provides full product functionality but inserts a watermark at the top of documents and limits document size to a few hundred paragraphs when no license is applied.

To remove these limitations, you can use either:
- **Free Trial**: Same as the full version; apply a license via code to unlock full capabilities.
- **30-day Temporary License**: Requested separately to test without evaluation restrictions. Details: [Get a Temporary License](https://purchase.aspose.com/temporary-license/)

**Purchased License**

After purchase, apply the license once per application domain before using any other Aspose.Words classes.

Pricing details: [Pricing Information](https://purchase.aspose.com/pricing/words/family/)

License protection guidelines: [Protecting Your Purchased License](https://purchase.aspose.com/orders/protecting-your-license-file) (available only to licensed users).

**License Applying Options**

Licenses can be applied from:
- An explicit file path
- The folder containing the Aspose.Words library
- The folder containing the client's application

The simplest method is to place the license file in the same folder as the Aspose.Words library and pass only the filename to `SetLicense`.

Calling `SetLicense` multiple times is harmless but inefficient.

**Load a License from a File**

```cpp
auto license = MakeObject<Aspose::Words::License>();
license->SetLicense(u"Aspose.Words.Cpp.lic");
```

**Load a License from a Stream Object**

```cpp
System::SharedPtr<System::IO::FileStream> stream = System::MakeObject<System::IO::FileStream>(u"Aspose.Words.Cpp.lic", System::IO::FileMode::Open);
auto license = MakeObject<Aspose::Words::License>();
license->SetLicense(stream);
```

**Changing the License File Name**

The license file name does not need to be `"Aspose.Words.Cpp.lic"`; you may rename it and use the new name in `SetLicense`.

**“Cannot find license filename” Exception**

Some browsers append a hidden `.xml` extension to downloaded license files (e.g., `Aspose.Words.Cpp.lic.xml`). Windows may hide file extensions by default, causing the file to appear as `Aspose.Words.Cpp.lic`. To resolve:
- Rename the file to remove the `.xml` extension.
- Disable “Hide extensions for known file types” in Windows Explorer settings.

**Using Multiple Aspose Products**

When using multiple Aspose products (e.g., Aspose.Words and Aspose.Cells):
- Call `SetLicense` separately for each product’s `License` class.
- Use fully qualified class names to avoid ambiguity:
  - `Aspose::Words::License`
  - `Aspose::Cells::License`

Even if you have a single license file (e.g., `"Aspose.Total.lic"`), each product must be licensed individually.

---