# Aspose.Words for C++ – Installation

---
**URL:** https://docs.aspose.com/words/cpp/installation.md

**Contents:**
- Install or Update Aspose.Words for C++ using NuGet
- Install or Update Aspose.Words for C++ using Package Manager Console
- Install Aspose.Words for C++ Manually
- Configure Aspose.Words for C++ in CMake Project
- Configure Aspose.Words for C++ in Visual Studio

---
title: "Installation and Configuration"
---

**Install or Update Aspose.Words for C++ using NuGet**

NuGet is the recommended method for installing and updating Aspose.Words for C++. In Visual Studio:

1. Open **Manage NuGet Packages**.
2. Search for `Aspose.Words.Cpp`.
3. Select the package and click **Install**.

NuGet automatically downloads the binaries and adds required project references.

You can also update to a specific version using the same interface.

**Install or Update Aspose.Words for C++ using Package Manager Console**

Use the Package Manager Console in Visual Studio:

- Install latest release:
  ```powershell
  Install-Package Aspose.Words.Cpp
  ```

- Install a specific version:
  ```powershell
  Install-Package Aspose.Words.Cpp -Version 21.3.0
  ```

- Update to the latest version:
  ```powershell
  Update-Package Aspose.Words.Cpp
  ```

After installation, the package is referenced in your project.

**Install Aspose.Words for C++ Manually**

Download the ZIP package from the [NuGet Gallery](https://www.nuget.org/packages/Aspose.Words.Cpp/) using the **Manual download** link.

Steps:

1. Extract the archive.
2. Add the `include` folder to your compiler’s include path.
3. Add the `lib` folder to your linker’s library path.
4. Link against the appropriate `.lib` files (e.g., `Aspose.Words.Cpp_vc14x64.lib`, `codeporting.translator.cs2cpp.framework_vc14x64.lib` for 64-bit Release).
5. Ensure corresponding DLLs are available at runtime (e.g., `Aspose.Words.Cpp_vc14x64.dll`).

---