# Aspose.Words for C++ - Save a Document

---
**URL:** https://docs.aspose.com/words/cpp/save-a-document.md

**Contents:**
- Save a Document
- Save to a File
- Save to a Stream
- Specify Save Options

---
title: "Save a Document in C++"
---

**Save a Document**

To save a document in Aspose.Words for C++, use the `Save` method of the `Document` class. The document can be saved in any format supported by Aspose.Words, as defined in the `SaveFormat` enumeration.

**Save to a File**

Save a document to a file by passing the file path to the `Save` method. The save format is inferred from the file extension.

```cpp
auto doc = System::MakeObject<Document>(u"input.doc");
doc->Save(u"output.pdf");
```

**Save to a Stream**

To save to a stream, pass a stream object (e.g., `MemoryStream`) to `Save`, and explicitly specify the save format.

```cpp
auto doc = System::MakeObject<Document>(u"input.docx");
auto stream = System::MakeObject<System::IO::MemoryStream>();
doc->Save(stream, SaveFormat::Pdf);
auto bytes = stream->ToArray();
```

**Specify Save Options**

Use classes derived from `SaveOptions` to control format-specific saving behavior. Each format has its own options class (e.g., `PdfSaveOptions`, `HtmlSaveOptions`, `ImageSaveOptions`).

```cpp
auto doc = System::MakeObject<Document>(u"input.docx");
auto saveOptions = System::MakeObject<HtmlSaveOptions>();
saveOptions->set_ExportTextInputFormFieldAsText(true);
doc->Save(u"output.html", saveOptions);
```

---