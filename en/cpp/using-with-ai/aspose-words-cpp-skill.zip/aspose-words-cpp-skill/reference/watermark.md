# Aspose.Words for C++ - Watermark

---
**URL:** https://docs.aspose.com/words/cpp/working-with-watermark.md

**Contents:**
- Add a Watermark to a Document
- Remove Watermark from a Document

---
title: "Working with Watermark"
---

**Add a Watermark to a Document**

A watermark is a background image displayed behind the document text. Aspose.Words for C++ supports text and image watermarks via the `Watermark` class and related options classes.

The `WatermarkType` enumeration defines three types: `Text`, `Image`, and `None`.

**Add Text Watermark**

Use `SetText()` with `TextWatermarkOptions` to insert a text watermark:

```cpp
auto doc = MakeObject<Document>(u"in.docx");
auto watermark = MakeObject<Watermark>();
auto options = MakeObject<TextWatermarkOptions>();
options->set_Text(u"Confidential");
options->set_FontName(u"Arial");
options->set_Color(System::Drawing::Color::get_Red());
options->set_Opacity(0.5);
options->set_IsSemitrasparent(true);
watermark->SetText(options);
doc->set_Watermark(watermark);
doc->Save(u"out.docx");
```

**Add Image Watermark**

Use `SetImage()` with `ImageWatermarkOptions` to insert an image watermark. The image can be provided as `System::Drawing::Image`, file path (`String`), or stream:

```cpp
auto doc = MakeObject<Document>(u"in.docx");
auto watermark = MakeObject<Watermark>();
auto options = MakeObject<ImageWatermarkOptions>();
options->set_Image(System::Drawing::Image::FromFile(u"watermark.png"));
options->set_Scale(0.5);
watermark->SetImage(options);
doc->set_Watermark(watermark);
doc->Save(u"out.docx");
```

**Remove Watermark from a Document**

Use `Watermark::Remove()` to remove a standard watermark:

```cpp
auto doc = MakeObject<Document>(u"in.docx");
doc->get_Watermark()->Remove();
doc->Save(u"out.docx");
```

If the watermark was inserted as a named `Shape`, assign a name before removal and delete by name:

```cpp
// During insertion:
watermark->set_Name(u"WaterMark");

// Later, to remove:
for (const auto& shape : System::IterateOver(doc->GetChildNodes(NodeType::Shape, true)))
{
    if (System::ObjectExt::Is<Shape>(shape))
    {
        auto sh = System::DynamicCast<Shape>(shape);
        if (sh->get_Name() == u"WaterMark")
        {
            sh->Remove();
        }
    }
}
```

---