# Aspose.Words for C++ - Use AI-powered Features

---
**URL:** https://docs.aspose.com/words/cpp/ai-powered-features.md

**Contents:**
- Supported AI Models
- Summarize a Document
- Translate a Document
- Grammar Checking

---
title: "AI-powered Features"
---

**Supported AI Models**

Aspose.Words for C++ supports integration with generative language models from OpenAI, Google, and Anthropic (Claude) families for document processing tasks such as summarization, translation, and grammar checking.

The list of supported models is defined in the `AiModelType` enumeration. A model instance is created using the `AiModel::Create()` method, followed by authentication via `WithApiKey()`.

```cpp
SharedPtr<AiModel> model = AiModel::Create(AiModelType::Gpt4OMini)->WithApiKey(u"API_KEY");
```

Self-hosted LLMs compatible with OpenAI endpoints can also be used by setting a custom URL:

```cpp
SharedPtr<AiModel> model = AiModel::Create(AiModelType::Gpt4OMini)->WithApiKey(u"API_KEY");
model->set_Url(u"https://my.a.com/");
```

**Summarize a Document**

The `Summarize` method generates a concise summary of one or more documents using AI models. You can control summary length using `SummarizeOptions::set_SummaryLength()` with values: `VeryShort`, `Short`, `Medium`, `Long`, `VeryLong`.

Single-document summary:

```cpp
void AiSummarize()
{
    auto doc = MakeObject<Document>(MyDir + u"Big document.docx");
    SharedPtr<AiModel> model = AiModel::Create(AiModelType::Gpt4OMini)->WithApiKey(u"API_KEY");
    auto options = MakeObject<SummarizeOptions>();
    options->set_SummaryLength(SummaryLength::Short);
    auto summary = model->Summarize(doc, options);
    summary->Save(ArtifactsDir + u"AI.AiSummarize.One.docx");
}
```

Multi-document summary:

```cpp
System::ArrayPtr<System::SharedPtr<Document>> docs = System::MakeArray<System::SharedPtr<Document>>({ doc1, doc2 });
options->set_SummaryLength(SummaryLength::Long);
auto multiSummary = model->Summarize(docs, options);
multiSummary->Save(ArtifactsDir + u"AI.AiSummarize.Multi.docx");
```

**Translate a Document**

The `Translate` method translates document content into a target language using Google generative models (e.g., Gemini). It supports over 300 languages defined in the `Language` enumeration.

The model automatically detects source languages per text fragment and translates accordingly; unrecognized fragments remain unchanged.

```cpp
void AiTranslate()
{
    auto doc = MakeObject<Document>(MyDir + u"Document.docx");
    SharedPtr<AiModel> model = AiModel::Create(AiModelType::GeminiFlashLatest)->WithApiKey(u"API_KEY");
    auto translatedDoc = model->Translate(doc, Language::Arabic);
    translatedDoc->Save(ArtifactsDir + u"AI.AiTranslate.docx");
}
```

**Grammar Checking**

The `CheckGrammar` method corrects grammatical and stylistic errors in a document using AI models (OpenAI, Google, or Claude). Stylistic improvements can be enabled via `CheckGrammarOptions::set_ImproveStylistics(true)`.

```cpp
void AiGrammar()
{
    auto doc = MakeObject<Document>(MyDir + u"Big document.docx");
    SharedPtr<AiModel> model = AiModel::Create(AiModelType::Gpt4OMini)->WithApiKey(u"API_KEY");
    auto grammarOptions = MakeObject<CheckGrammarOptions>();
    grammarOptions->set_ImproveStylistics(true);
    auto proofedDoc = model->CheckGrammar(doc, grammarOptions);
    proofedDoc->Save(ArtifactsDir + u"AI.AiGrammar.docx");
}
```

---