# Aspose.Words for C++ - Split Large Documents

---
**URL:** https://docs.aspose.com/words/cpp/split-a-document.md

**Contents:**
- Split a Document Using Different Criteria
- Split a Document by Sections
- Split by Pages
- Split a Document Page by Page
- Split a Document by Page Ranges
- Merge the Split Document with Another Document

---
title: "Split a Document in C++"
---

**Split a Document Using Different Criteria**

Aspose.Words allows splitting EPUB or HTML documents into chapters using various criteria while preserving style and layout. The splitting behavior is controlled via the `DocumentSplitCriteria` enumeration, which supports:

- `HEADING_PARAGRAPH`: Split by heading paragraphs  
- `SECTION_BREAK`: Split by section breaks  
- `COLUMN_BREAK`: Split by column breaks  
- `PAGE_BREAK`: Split by page breaks  

Multiple criteria can be combined. When saving to HTML, each chapter becomes a separate HTML file. For EPUB, the output remains a single file, but the internal structure reflects the split criteria for reader applications.

> **Note:** `DocumentSplitCriteria` has no effect when saving to MHTML.

**Split a Document by Sections**

To split a document by section breaks, set `DocumentSplitCriteria::SECTION_BREAK` in the save options.

Example:

```cpp
auto doc = MakeObject<Document>(u"input.docx");

auto saveOptions = MakeObject<HtmlSaveOptions>();
saveOptions->set_DocumentSplitCriteria(DocumentSplitCriteria::SectionBreak);

doc->Save(u"output.html", saveOptions);
```

**Split by Pages**

Use the `ExtractPages` method of the `Document` class to extract specific pages or page ranges.

> **Note:** Layout fidelity may vary depending on document complexity.

**Split a Document Page by Page**

Extract each page as a separate document.

Example:

```cpp
auto doc = MakeObject<Document>(u"input.docx");

for (int i = 0; i < doc->get_PageCount(); ++i)
{
    auto extractedDoc = doc->ExtractPages({ i, 1 });
    extractedDoc->Save(String::Format(u"output_page_{0}.docx", i + 1));
}
```

**Split a Document by Page Ranges**

Extract specific page ranges using zero-based start index and count.

Example:

```cpp
auto doc = MakeObject<Document>(u"input.docx");

// Extract pages 2–4 (0-based indices: start=1, count=3)
auto extractedDoc = doc->ExtractPages(1, 3);
extractedDoc->Save(u"output_pages_2-4.docx");
```

**Merge the Split Document with Another Document**

After splitting, you can merge extracted documents with others using `Document::AppendDocument`.

Example:

```cpp
auto doc1 = MakeObject<Document>(u"part1.docx");
auto doc2 = MakeObject<Document>(u"part2.docx");

doc1->AppendDocument(doc2, ImportFormatMode::KeepSourceFormatting);
doc1->Save(u"merged.docx");
```

---