# Aspose.Words for C++ - Create or Load a Document

---
**URL:** https://docs.aspose.com/words/cpp/create-or-load-a-document.md

**Contents:**
- Create or Load a Document

---
title: "Create, Load, and Configure Document Loading in C++"
---

**Create or Load a Document**

The `Document` class in Aspose.Words for C++ represents a document loaded into memory. It supports multiple constructors to create blank documents or load existing ones from files, streams, or byte arrays.

To create a blank document, use the default constructor:

```cpp
auto doc = MakeObject<Document>();
```

A newly created document contains one section with default parameters, one empty paragraph, and built-in styles—equivalent to a new document in Microsoft Word. The default paper size is `PaperSize::Letter`.

To load a document from a file, pass the file path to the `Document` constructor:

```cpp
auto doc = MakeObject<Document>(u"Document.docx");
```

To load a document from a stream, pass a stream object containing the document:

```cpp
auto stream = MakeObject<System::IO::FileStream>(u"Document.docx", System::IO::FileMode::Open);
auto doc = MakeObject<Document>(stream);
```

The document format is automatically detected based on its file extension or header bytes.

---
**URL:** https://docs.aspose.com/words/cpp/detect-file-format-and-check-format-compatibility.md

**Contents:**
- Detect File Format and Check Format Compatibility

---
title: Detect File Format and Check Format Compatibility
---

**Detect File Format and Check Format Compatibility**

Before loading a document, you can detect its format using `FileFormatUtil::DetectFileFormat`, which inspects only the file header and avoids exceptions for unsupported formats. It returns a `FileFormatInfo` object containing metadata such as load format and encryption status.

```cpp
auto info = FileFormatUtil::DetectFileFormat(u"Document.docx");
auto loadFormat = info->get_LoadFormat();
bool isEncrypted = info->get_IsEncrypted();
```

This method is useful when file extensions are unreliable (e.g., RTF files with `.doc` extension). Note: `DetectFileFormat` does not guarantee successful loading—corruption or unsupported features may still cause exceptions during full parsing.

---
**URL:** https://docs.aspose.com/words/cpp/specify-load-options.md  

**Contents:**
- Specify Load Options

---
title: Specify Load Options
---

**Specify Load Options**

The `LoadOptions` class provides fine-grained control over document loading behavior. It supports version-specific rendering, language preferences, external resource handling, and memory optimization.

**Set Microsoft Word Version**  
Documents may render differently across Word versions. Use `LoadOptions::set_MswVersion()` to match a specific version:

```cpp
auto loadOptions = MakeObject<LoadOptions>();
loadOptions->set_MswVersion(MsWordVersion::Word2010);
auto doc = MakeObject<Document>(u"Document.docx", loadOptions);
```

**Set Language Preferences**  
To match Microsoft Word’s language behavior, configure `LanguagePreferences`:

```cpp
auto loadOptions = MakeObject<LoadOptions>();
loadOptions->get_LanguagePreferences()->Add(EditingLanguage::Japanese);
auto doc = MakeObject<Document>(u"Document.docx", loadOptions);
```

**Handle Warnings During Load**  
Implement `IWarningCallback` to capture issues like unsupported features or malformed content:

```cpp
class MyWarningCallback : public IWarningCallback
{
public:
    void Warning(SharedPtr<WarningInfo> info) override
    {
        // Log or handle warning
    }
};

auto loadOptions = MakeObject<LoadOptions>();
loadOptions->set_WarningCallback(MakeObject<MyWarningCallback>());
auto doc = MakeObject<Document>(u"Document.docx", loadOptions);
```

**Set Encoding Explicitly**  
Override auto-detected encoding for legacy documents:

```cpp
auto loadOptions = MakeObject<LoadOptions>();
loadOptions->set_Encoding(System::Text::Encoding::get_ASCII());
auto doc = MakeObject<Document>(u"LegacyDocument.txt", loadOptions);
```

**Load Encrypted Documents**  
Use `LoadOptions` with a password to open encrypted files:

```cpp
auto loadOptions = MakeObject<LoadOptions>();
loadOptions->set_Password(u"password");
auto doc = MakeObject<Document>(u"Encrypted.docx", loadOptions);
```

If encryption status is unknown, detect it first using `FileFormatInfo::get_IsEncrypted()`:

```cpp
auto info = FileFormatUtil::DetectFileFormat(u"Document.docx");
if (info->get_IsEncrypted())
{
    // Prompt for password or handle accordingly
}
```

And other examples.

---