# Aspose.Words for C++ - Sign with Digital Signature

---
**URL:** https://docs.aspose.com/words/cpp/working-with-digital-signatures.md

**Contents:**
- Supported Formats
- Limitations of Digital Signatures
- Detect, Count, and Verify Digital Signatures
- Create a Digital Signature
  - Sign a Document
  - Add a Signature Line
  - Sign a Generated PDF Document
- Retrieve the Digital Signature Value
- Remove Digital Signatures

---
title: "Work with Digital Signatures in C++"
---

**Supported Formats**

Aspose.Words supports working with digital signatures on the following input formats: DOC, OOXML (DOCX, DOCM, DOTX, DOTM), and ODT. Generated output can be signed in PDF or XPS format.

**Limitations of Digital Signatures**

| Limitation | Alternative option |
|------------|--------------------|
| Digital signatures are lost when a document is loaded and saved. | Detect signatures before processing and warn users or re-apply them afterward. |
| Digital signatures on macros are not supported. | Remove macros or use Microsoft Word to sign macro-enabled files after processing. |

**Detect, Count, and Verify Digital Signatures**

Use `FileFormatUtil::DetectFileFormat()` and `FileFormatInfo::get_HasDigitalSignature()` to detect the presence of signatures (but not validate them). To validate and count signatures, load them using `DigitalSignatureUtil::LoadSignatures()` and iterate through the `DigitalSignatureCollection`. Use `get_IsValid()` to verify each signature and `get_Count()` to count them.

```cpp
// Detect presence of signatures
auto fileInfo = FileFormatUtil::DetectFileFormat("document.docx");
bool hasSignature = fileInfo->get_HasDigitalSignature();

// Load and verify signatures
auto signatures = DigitalSignatureUtil::LoadSignatures("document.docx");
for (int i = 0; i < signatures->get_Count(); i++)
{
    auto signature = signatures->idx_get(i);
    bool isValid = signature->get_IsValid();
}
```

**Create a Digital Signature**

To sign a document, you need a certificate. Aspose.Words supports X.509 certificates via the `CertificateHolder::Create()` method.

**Sign a Document**

Use `DigitalSignatureUtil::Sign()` with a `CertificateHolder` and optional `SignOptions`.

```cpp
auto certHolder = CertificateHolder::Create("certificate.pfx", "password");
auto signOptions = MakeObject<SignOptions>();
signOptions->set_SignTime(DateTime::get_Now());

DigitalSignatureUtil::Sign("input.docx", "output.docx", certHolder, signOptions);
```

**Add a Signature Line**

A signature line is a visual placeholder for a digital signature. Insert it using `DocumentBuilder::InsertSignatureLine()` and configure with `SignatureLineOptions`.

```cpp
auto doc = MakeObject<Document>();
auto builder = MakeObject<DocumentBuilder>(doc);

auto options = MakeObject<SignatureLineOptions>();
options->set_ProviderId(System::Guid::Parse("CF54E822-CB52-4865-A25A-90D45372F5D1"));
options->set_ShowDate(true);
options->set_DefaultInstructions(true);

builder->InsertSignatureLine(options);

doc->Save("document-with-signature-line.docx");
```

**Sign a Generated PDF Document**

Use `PdfDigitalSignatureDetails` to sign a PDF during saving.

```cpp
auto doc = MakeObject<Document>("input.docx");

auto signDetails = MakeObject<PdfDigitalSignatureDetails>();
signDetails->set_CertificateHolder(CertificateHolder::Create("certificate.pfx", "password"));
signDetails->set_HashAlgorithm(SignHashAlgorithm::Sha256);
signDetails->set_SignatureLineId(System::Guid::Empty);
signDetails->set_SignatureText("Digitally signed by Aspose.Words");

auto saveOptions = MakeObject<PdfSaveOptions>();
saveOptions->set_DigitalSignatureDetails(signDetails);

doc->Save("signed.pdf", saveOptions);
```

**Retrieve the Digital Signature Value**

Access the raw signature bytes using `DigitalSignature::get_SignatureValue()`.

```cpp
auto signatures = DigitalSignatureUtil::LoadSignatures("signed.docx");
auto signature = signatures->idx_get(0);
ArrayPtr<uint8_t> signatureValue = signature->get_SignatureValue();
```

**Remove Digital Signatures**

Remove all signatures from a document using `DigitalSignatureUtil::RemoveAllSignatures()`.

```cpp
DigitalSignatureUtil::RemoveAllSignatures("signed.docx", "unsigned.docx");
```

> **Note:** Only all signatures can be removed at once; selective removal is not supported.

---