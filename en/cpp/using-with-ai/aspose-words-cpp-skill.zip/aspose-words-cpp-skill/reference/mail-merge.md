# Aspose.Words for C++ - Mail Merge

---
**URL:** https://docs.aspose.com/words/cpp/mail-merge-and-reporting.md

**Contents:**
- Mail Merge and Reporting Overview
- Mechanism and Main Components of Mail Merge
- What is a Mail Merge Template
- Advanced Mail Merge Features
- Clean Up Before or During a Mail Merge Operation
- Insert Checkboxes, Text Input, or Images during Mail Merge
- Types of Mail Merge Operation
- Mail Merge with Regions
- Nested Mail Merge with Regions
- Simple Mail Merge Operation
---

**Mail Merge and Reporting Overview**

Mail Merge is a feature for quickly creating documents such as letters, labels, and envelopes. Aspose.Words for C++ extends standard Mail Merge functionality into a full-fledged reporting solution, enabling creation of complex documents like reports, catalogs, inventories, and invoices.

Key capabilities include:
- Designing reports in Microsoft Word using standard Mail Merge fields
- Defining repeating regions (e.g., order line items)
- Inserting images during merge
- Executing custom logic via Mail Merge event handlers
- Filling documents with data from any data source

The `Aspose::Words::MailMerging` namespace provides all Mail Merge functionality.

**Mechanism and Main Components of Mail Merge**

A Mail Merge operation combines a *mail merge template* (a document with merge fields) and a *data source* (e.g., database, file) to generate one or more *merged documents*.

Merge fields are special placeholders inserted into the template where data from the data source will be placed.

**What is a Mail Merge Template**

A Mail Merge template is a document containing fixed content and merge fields where variable data will be inserted. Templates can be created manually in Microsoft Word or programmatically using `DocumentBuilder`. Supported formats include DOC, DOCX, DOT, DOTX, and RTF.

**Advanced Mail Merge Features**

Aspose.Words provides advanced customization options for Mail Merge:

- **Rules**: Use `FieldNext`, `FieldNextIf`, and `FieldSkipIf` to control record flow:
  - `FieldNext`: Insert next data record into the current document
  - `FieldNextIf`: Insert next record only if condition is true
  - `FieldSkipIf`: Skip current record if condition is true

- **Template Analysis**:
  - `MailMerge::GetFieldNames()`: Get all merge field names
  - `MailMerge::GetRegionsHierarchy()`: Get region structure as `MailMergeRegionInfo`

- **Mapped Fields**: Automatically map data source columns to differently named merge fields using `get_MappedDataFields()->Add(u"MergeFieldName", u"DataSourceFieldName")`

**Clean Up Before or During a Mail Merge Operation**

Cleanup options help produce clean output by removing unnecessary content:

- `DeleteFields()`: Remove all merge fields without executing merge
- `CleanupOptions`: Configure removal behavior with flags:
  - `RemoveEmptyParagraphs`: Delete paragraphs left empty after merge
  - `RemoveUnusedFields`: Remove fields without matching data
  - `RemoveContainingFields`: Remove outer fields (e.g., IF) containing merged fields
  - `RemoveEmptyTableRows`: Delete table rows with empty merge fields

Example:
```cpp
doc->get_MailMerge()->set_CleanupOptions(
    MailMergeCleanupOptions::RemoveEmptyParagraphs |
    MailMergeCleanupOptions::RemoveUnusedFields);
doc->get_MailMerge()->Execute(fieldNames, values);
```

**Insert Checkboxes, Text Input, or Images during Mail Merge**

Customize merge behavior using `IFieldMergingCallback`:

- **Form Fields**: Insert checkboxes or text input fields by handling `FieldMerging`:
  ```cpp
  class HandleMergeField : public IFieldMergingCallback
  {
  public:
      void FieldMerging(SharedPtr<FieldMergingArgs> args) override
      {
          if (args->get_DocumentFieldName() == u"Checkbox")
          {
              auto builder = MakeObject<DocumentBuilder>(args->get_Document());
              builder->MoveToMergeField(args->get_DocumentFieldName());
              builder->InsertCheckBox(u"", false, 0);
              args->set_Text(u"");
          }
      }
      void ImageFieldMerging(SharedPtr<ImageFieldMergingArgs> args) override { }
  };
  ```

- **Images**: Insert images from files, streams, or BLOBs using `ImageFieldMergingArgs`:
  ```cpp
  void ImageFieldMerging(SharedPtr<ImageFieldMergingArgs> args) override
  {
      args->set_ImageFileName(u"image" + args->get_RecordIndex() + u".png");
  }
  ```

**Types of Mail Merge Operation**

Two types of Mail Merge are supported:

- **Simple Mail Merge**: Repeats the entire document for each data record. Suitable for templates without regions.
- **Mail Merge with Regions**: Repeats only designated regions (`TableStart:Name` to `TableEnd:Name`) per record. Allows dynamic document growth.

Simple Mail Merge is a special case of Mail Merge with regions where the region is the entire document.

**Mail Merge with Regions**

Mail Merge with regions enables dynamic document growth by repeating specific content blocks per data record. Regions are defined using `TableStart:RegionName` and `TableEnd:RegionName` fields.

Requirements:
- Start and end fields must be in the same row or cell
- Field names must match data source column names (unless mapped)
- C++ requires custom implementation of `IMailMergeDataSource` or `IMailMergeDataSourceRoot`

Example with SQLite:
```cpp
class OrderDataSource : public IMailMergeDataSource
{
public:
    bool GetValue(String fieldName, SharedPtr<IFieldMergerValue>& value) override
    {
        // Return value for current record
    }
    bool MoveNext() override { /* Advance to next record */ }
    SharedPtr<IMailMergeDataSource> GetChildDataSource(String regionName) override
    {
        // Return child data source for nested regions
    }
};
```

**Nested Mail Merge with Regions**

Nested Mail Merge handles hierarchical data by nesting regions (e.g., Orders → Items). Parent regions define `TableStart:Parent`, and child regions define `TableStart:Child` inside them.

To link parent and child records, implement `GetChildDataSource` to return a data source filtered by the current parent's key.

Example:
```cpp
SharedPtr<IMailMergeDataSource> GetChildDataSource(String regionName) override
{
    if (regionName == u"Item")
    {
        return MakeObject<ItemDataSource>(m_currentOrderId);
    }
    return nullptr;
}
```

**Simple Mail Merge Operation**

Simple Mail Merge fills merge fields in a template with data from a single data source. Use `MailMerge::Execute()` with arrays of field names and values.

To generate multiple documents (one per record), loop through data and call `Execute()` for each:

```cpp
while (dataReader->Read())
{
    auto doc = MakeObject<Document>(u"Template.docx");
    doc->get_MailMerge()->Execute(
        System::MakeArray<String>({u"Name", u"Address"}),
        System::MakeArray<SharedPtr<Object>>({
            ObjectExt::Box<String>(dataReader->GetString(0)),
            ObjectExt::Box<String>(dataReader->GetString(1))
        }));
    doc->Save(String::Format(u"Output_{0}.docx", recordIndex++));
}
```

---