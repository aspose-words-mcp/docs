# Aspose.Words for C++ - System Requirements

---
**URL:** https://docs.aspose.com/words/cpp/system-requirements.md

**Contents:**
- Supported Operating Systems
- Development Environment (Windows, Linux, macOS)

---
title: "System Requirements"
---

**Supported Operating Systems**

Aspose.Words for C++ supports 64-bit and 32-bit versions of the following operating systems:

- **Microsoft Windows**: Windows 2008 Server through Windows 2022 Server (x64/x86), Windows Vista through Windows 10 (x64/x86)
- **Linux**: Ubuntu, Fedora, OpenSUSE, CentOS, and other distributions
- **macOS**: macOS 12.0 or later for both `x86_64` and `arm64` architectures

**Development Environment**

**Windows**  
Supported in development environments that support the Microsoft Visual Studio v143 Platform Toolset. Explicitly supported:
- Microsoft Visual Studio 2022

**Linux**  
Requires a compiler supporting the C++14 standard. Explicitly supported:
- Clang 3.9.1 or later

**macOS**  
Supported in the following development environments:
- Xcode 12.5.1 or later
- Clang and libc++ (shipped by default with Xcode)

---