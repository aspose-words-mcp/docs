# Aspose.Words for C++ - Comparison

---
**URL:** https://docs.aspose.com/words/cpp/compare-documents.md

**Contents:**
- Compare Documents
- Limitations and Supported File Formats
- Compare Two Documents
- Specify Advanced Comparison Options

---
title: "Compare Documents in C++"
---

**Compare Documents**

Document comparison identifies changes between two documents and represents them as revisions in the first document. Aspose.Words for C++ enables programmatic comparison of documents in any supported formats, detecting differences in content, formatting, headers/footers, tables, and more.

The comparison operates at the character or word level: if a word contains at least one changed character, the entire word is marked as changed. This behavior aligns with Microsoft Word’s comparison algorithm.

**Limitations and Supported File Formats**

- Documents must not contain existing revisions before comparison (a Microsoft Word limitation).
- Any two documents within the [supported file formats](/words/cpp/supported-document-formats/) can be compared.
- Document objects can be created from scratch or loaded from files and compared directly.

**Compare Two Documents**

Use the `Document::Compare()` method to compare two documents. Differences from the second document relative to the first appear as revisions in the first document.

The documents are considered *equal* only if no revisions are generated — meaning identical text and formatting. Differences in elements like styles (e.g., style insertion/deletion) may not produce revisions, even if present.

**Example: Check if two documents are equal**

```cpp
auto doc1 = MakeObject<Document>(u"document1.docx");
auto doc2 = MakeObject<Document>(u"document2.docx");

doc1->Compare(doc2, u"Author", System::DateTime::get_Now());

if (doc1->get_Revisions()->get_Count() == 0)
{
    Console::WriteLine(u"Documents are equal.");
}
else
{
    Console::WriteLine(u"Documents differ.");
}
```

**Example: Compare documents with existing revisions**

```cpp
auto doc1 = MakeObject<Document>(u"document1.docx");
auto doc2 = MakeObject<Document>(u"document2.docx");

// Clear existing revisions before comparison
doc1->get_Revisions()->AcceptAll();
doc2->get_Revisions()->AcceptAll();

doc1->Compare(doc2, u"Author", System::DateTime::get_Now());
```

**Specify Advanced Comparison Options**

Use the `CompareOptions` class to customize comparison behavior:

- **Granularity**: Set to `Granularity::CharLevel` or `Granularity::WordLevel` to control change tracking resolution.
- **Target**: Set to `ComparisonTargetType::New` or `ComparisonTargetType::Current` to control which document shows revisions.
- **Ignore* properties**: Skip specific elements:
  - `get_IgnoreHeadersAndFooters()`
  - `get_IgnoreFormatting()`
  - `get_IgnoreComments()`
  - `get_IgnoreFootnotes()`
  - `get_IgnoreTextboxes()`
  - `get_IgnoreFields()`
  - etc.

**Example: Compare with advanced options**

```cpp
auto doc1 = MakeObject<Document>(u"document1.docx");
auto doc2 = MakeObject<Document>(u"document2.docx");

auto options = MakeObject<CompareOptions>();
options->set_Granularity(Granularity::CharLevel);
options->set_Target(ComparisonTargetType::New);
options->set_IgnoreFormatting(true);
options->set_IgnoreHeadersAndFooters(true);

doc1->Compare(doc2, u"Author", System::DateTime::get_Now(), options);
```

---