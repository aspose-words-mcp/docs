# Aspose.Words for C++ - Conversion

---
**URL:** https://docs.aspose.com/words/cpp/convert-a-document.md

**Contents:**
- What Is Document Conversion
- Convert to PDF
- Convert to Image
- Convert to Excel (XLSX)
- Convert to HTML, MHTML, or EPUB
- Convert Multi-page Document to Image

---
title: "Convert a Document in C++"
---

**What Is Document Conversion**

Document conversion in Aspose.Words for C++ is a two-step process: load a document into a `Document` object and save it in the desired format using one of the `Save` methods. Aspose.Words supports conversion between any of its supported load and save formats, including Microsoft Word (DOCX, DOC), OpenDocument (ODT, OTT), web (HTML, MHTML), text (Markdown, TXT), PDF, images (JPG, PNG, TIFF), and spreadsheets (XLSX).

The conversion process involves internal rendering and layout calculations, but from the user’s perspective, it is straightforward:

1. Load the document:
   ```cpp
   auto doc = System::MakeObject<Aspose::Words::Document>(u"input.docx");
   ```

2. Save in the target format:
   ```cpp
   doc->Save(u"output.pdf");
   ```

**Convert to PDF**

PDF conversion is a key feature, preserving document layout and appearance across platforms. Aspose.Words uses its own layout engine to closely mimic Microsoft Word’s rendering.

- Convert DOCX/DOC to PDF:
  ```cpp
  auto doc = System::MakeObject<Aspose::Words::Document>(u"input.docx");
  doc->Save(u"output.pdf");
  ```

- Convert to specific PDF standards (e.g., PDF/A-1b):
  ```cpp
  auto options = System::MakeObject<Aspose::Words::Saving::PdfSaveOptions>();
  options->set_Compliance(Aspose::Words::Saving::PdfCompliance::PdfA1b);
  doc->Save(u"output_pdfa.pdf", options);
  ```

- Convert images to PDF:
  ```cpp
  auto doc = System::MakeObject<Aspose::Words::Document>();
  auto builder = System::MakeObject<Aspose::Words::DocumentBuilder>(doc);
  builder->InsertImage(u"image.jpg");
  doc->Save(u"output.pdf");
  ```

- Optimize output size:
  ```cpp
  auto options = System::MakeObject<Aspose::Words::Saving::PdfSaveOptions>();
  options->set_OptimizeOutput(true);
  doc->Save(u"optimized.pdf", options);
  ```

**Convert to Image**

Documents can be exported to raster image formats (JPG, PNG, BMP, TIFF, GIF, WebP). Use `ImageSaveOptions` for fine-grained control.

- Basic DOCX to JPEG conversion:
  ```cpp
  auto doc = System::MakeObject<Aspose::Words::Document>(u"input.docx");
  auto options = System::MakeObject<Aspose::Words::Saving::ImageSaveOptions>(Aspose::Words::SaveFormat::Jpeg);
  doc->Save(u"output.jpg", options);
  ```

- Export specific pages (e.g., first page only):
  ```cpp
  auto options = System::MakeObject<Aspose::Words::Saving::ImageSaveOptions>(Aspose::Words::SaveFormat::Png);
  options->set_PageSet(System::MakeObject<Aspose::Words::Saving::PageSet>(0));
  doc->Save(u"first-page.png", options);
  ```

- Control resolution and quality:
  ```cpp
  auto options = System::MakeObject<Aspose::Words::Saving::ImageSaveOptions>(Aspose::Words::SaveFormat::Png);
  options->set_Resolution(300);
  options->set_JpegQuality(85);
  doc->Save(u"high-res.png", options);
  ```

**Convert to Excel (XLSX)**

Documents in any supported load format can be saved as XLSX using `XlsxSaveOptions`.

- Basic DOCX to XLSX:
  ```cpp
  auto doc = System::MakeObject<Aspose::Words::Document>(u"input.docx");
  doc->Save(u"output.xlsx");
  ```

- Perform find-and-replace before saving:
  ```cpp
  auto doc = System::MakeObject<Aspose::Words::Document>(u"input.docx");
  doc->get_Range()->Replace(u"old", u"new", System::MakeObject<Aspose::Words::Finding::FindReplaceOptions>());
  doc->Save(u"output.xlsx");
  ```

- Control compression level:
  ```cpp
  auto options = System::MakeObject<Aspose::Words::Saving::XlsxSaveOptions>();
  options->set_CompressionLevel(Aspose::Words::Saving::CompressionLevel::Maximum);
  doc->Save(u"compressed.xlsx", options);
  ```

**Convert to HTML, MHTML, or EPUB**

Documents can be exported to web-friendly formats. Use `HtmlSaveOptions` for customization.

- Basic DOCX to HTML:
  ```cpp
  auto doc = System::MakeObject<Aspose::Words::Document>(u"input.docx");
  doc->Save(u"output.html", Aspose::Words::SaveFormat::Html);
  ```

- Export round-trip information (preserves Word-specific features):
  ```cpp
  auto options = System::MakeObject<Aspose::Words::Saving::HtmlSaveOptions>();
  options->set_ExportRoundtripInformation(true);
  doc->Save(u"output.html", options);
  ```

- Save resources to custom folders:
  ```cpp
  auto options = System::MakeObject<Aspose::Words::Saving::HtmlSaveOptions>();
  options->set_ResourceFolder(u"Resources");
  options->set_ImagesFolder(u"Resources/Images");
  options->set_FontsFolder(u"Resources/Fonts");
  doc->Save(u"output.html", options);
  ```

- Embed fonts as Base64:
  ```cpp
  auto options = System::MakeObject<Aspose::Words::Saving::HtmlSaveOptions>();
  options->set_ExportFontsAsBase64(true);
  doc->Save(u"output.html", options);
  ```

- Convert to EPUB:
  ```cpp
  auto options = System::MakeObject<Aspose::Words::Saving::HtmlSaveOptions>(Aspose::Words::SaveFormat::Epub);
  options->set_ExportFontResources(true);
  doc->Save(u"output.epub", options);
  ```

**Convert Multi-page Document to Image**

Multi-page documents can be exported to multi-frame or composite images using `MultiPageLayout`.

- Horizontal layout (pages side-by-side):
  ```cpp
  auto doc = System::MakeObject<Aspose::Words::Document>(u"input.docx");
  auto options = System::MakeObject<Aspose::Words::Saving::ImageSaveOptions>(Aspose::Words::SaveFormat::Jpeg);
  options->get_PageLayout()->set_MultiPageLayout(Aspose::Words::Saving::MultiPageLayout::Horizontal());
  doc->Save(u"output.jpg", options);
  ```

- Grid layout (pages in grid):
  ```cpp
  auto options = System::MakeObject<Aspose::Words::Saving::ImageSaveOptions>(Aspose::Words::SaveFormat::Png);
  options->get_PageLayout()->set_MultiPageLayout(Aspose::Words::Saving::MultiPageLayout::Grid());
  doc->Save(u"output.png", options);
  ```

- Multi-frame TIFF (one frame per page):
  ```cpp
  auto options = System::MakeObject<Aspose::Words::Saving::ImageSaveOptions>(Aspose::Words::SaveFormat::Tiff);
  options->get_PageLayout()->set_MultiPageLayout(Aspose::Words::Saving::MultiPageLayout::TiffFrames());
  doc->Save(u"output.tiff", options);
  ```

- Customize background and borders:
  ```cpp
  auto layout = options->get_PageLayout();
  layout->set_BackColor(System::Drawing::Color::get_White());
  layout->set_BorderColor(System::Drawing::Color::get_Black());
  layout->set_BorderWidth(2.0f);
  ```

---