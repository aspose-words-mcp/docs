# Aspose.Words for C++ - Merge Documents
---
**URL:** https://docs.aspose.com/words/cpp/insert-and-append-documents.md

**Contents:**
- Insert a Document
- Insert a Document During Find and Replace Operation
- Insert a Document During Mail Merge Operation
- Insert a Document at Bookmark
- Append a Document
- Import and Insert Nodes Manually
- Common Properties for Insert and Append Documents
---

title: "Insert and Append Documents"

---

**Insert a Document**

In Aspose.Words for C++, a document is represented as a tree of nodes. Inserting one document into another involves copying nodes from the source document tree into the destination document.

You can insert a document at the current cursor position using the `DocumentBuilder::InsertDocument` method, which behaves similarly to inserting a document in Microsoft Word.

```cpp
System::SharedPtr<Aspose::Words::Document> srcDoc = System::MakeObject<Aspose::Words::Document>(u"Source.docx");
System::SharedPtr<Aspose::Words::Document> dstDoc = System::MakeObject<Aspose::Words::Document>(u"Destination.docx");
System::SharedPtr<Aspose::Words::DocumentBuilder> builder = System::MakeObject<Aspose::Words::DocumentBuilder>(dstDoc);
builder->InsertDocument(srcDoc, Aspose::Words::ImportFormatMode::UseDestinationStyles);
dstDoc->Save(u"Output.docx");
```

**Insert a Document During Find and Replace Operation**

You can insert content from a source document in place of specific text (e.g., placeholders like `[INTRODUCTION]`) during a find-and-replace operation by handling the `Replacing` event.

```cpp
System::SharedPtr<Aspose::Words::Document> dstDoc = System::MakeObject<Aspose::Words::Document>(u"Template.docx");
System::SharedPtr<Aspose::Words::Document> srcDoc = System::MakeObject<Aspose::Words::Document>(u"Content.docx");

System::SharedPtr<Aspose::Words::Replacing::IReplacingCallback> callback = System::MakeObject<Aspose::Words::Replacing::ReplaceEvaluatorInsertDocument>(srcDoc);
dstDoc->get_Range()->Replace(System::MakeObject<System::Text::Regex>(u"\\[INTRODUCTION\\]"), callback, System::MakeObject<Aspose::Words::Replacing::ReplaceOptions>(true));
dstDoc->Save(u"Output.docx");
```

Where `ReplaceEvaluatorInsertDocument` is a custom class implementing `IReplacingCallback` to insert the source document at the matched position.

**Insert a Document During Mail Merge Operation**

You can insert content from a source document into a merge field (e.g., `[Summary]`) during a mail merge by handling the `MergeField` event.

```cpp
System::SharedPtr<Aspose::Words::Document> dstDoc = System::MakeObject<Aspose::Words::Document>(u"MailMergeTemplate.docx");
System::SharedPtr<Aspose::Words::Document> srcDoc = System::MakeObject<Aspose::Words::Document>(u"Summary.docx");

System::SharedPtr<Aspose::Words::MailMerging::IMailMergeDataSource> dataSource = /* your data source */;
System::SharedPtr<Aspose::Words::MailMerging::IMailMergeCallback> callback = System::MakeObject<Aspose::Words::MailMerging::MailMergeCallbackInsertDocument>(srcDoc);
dstDoc->get_MailMerge()->set_Callback(callback);
dstDoc->get_MailMerge()->Execute(dataSource);
dstDoc->Save(u"Output.docx");
```

Where `MailMergeCallbackInsertDocument` is a custom class implementing `IMailMergeCallback` to insert the source document when the merge field name matches.

**Insert a Document at Bookmark**

To insert a document at a specific bookmark, move the `DocumentBuilder` to the bookmark and call `InsertDocument`.

```cpp
System::SharedPtr<Aspose::Words::Document> dstDoc = System::MakeObject<Aspose::Words::Document>(u"Template.docx");
System::SharedPtr<Aspose::Words::Document> srcDoc = System::MakeObject<Aspose::Words::Document>(u"Content.docx");
System::SharedPtr<Aspose::Words::DocumentBuilder> builder = System::MakeObject<Aspose::Words::DocumentBuilder>(dstDoc);

builder->MoveToBookmark(u"InsertHere");
builder->InsertDocument(srcDoc, Aspose::Words::ImportFormatMode::UseDestinationStyles);
dstDoc->Save(u"Output.docx");
```

> **Note:** The bookmark should not enclose multiple paragraphs or content you want preserved.

**Append a Document**

To append a document to the end of another, use `Document::AppendDocument`.

```cpp
System::SharedPtr<Aspose::Words::Document> dstDoc = System::MakeObject<Aspose::Words::Document>(u"Main.docx");
System::SharedPtr<Aspose::Words::Document> srcDoc = System::MakeObject<Aspose::Words::Document>(u"ToAdd.docx");

dstDoc->AppendDocument(srcDoc, Aspose::Words::ImportFormatMode::KeepSourceFormatting);
dstDoc->Save(u"Output.docx");
```

> **Note:** `AppendChild` is a node-level method (e.g., for appending paragraphs), not for appending full documents.

**Import and Insert Nodes Manually**

To insert specific nodes (e.g., a single paragraph or section), import them using `NodeImporter::ImportNode`, then insert using `InsertAfter`, `InsertBefore`, or `AppendChild`.

```cpp
System::SharedPtr<Aspose::Words::Document> srcDoc = System::MakeObject<Aspose::Words::Document>(u"Source.docx");
System::SharedPtr<Aspose::Words::Document> dstDoc = System::MakeObject<Aspose::Words::Document>(u"Destination.docx");

System::SharedPtr<Aspose::Words::Node> srcPara = srcDoc->get_FirstSection()->get_Body()->get_Paragraphs()->idx_get(0);
System::SharedPtr<Aspose::Words::NodeImporter> importer = System::MakeObject<Aspose::Words::NodeImporter>(srcDoc, dstDoc, Aspose::Words::ImportFormatMode::UseDestinationStyles);
System::SharedPtr<Aspose::Words::Node> importedPara = importer->ImportNode(srcPara, true);

dstDoc->get_FirstSection()->get_Body()->AppendChild(importedPara);
dstDoc->Save(u"Output.docx");
```

> **Note:** Importing creates a copy of the node suitable for insertion into the destination document.

**Common Properties for Insert and Append Documents**

Both `InsertDocument` and `AppendDocument` accept `ImportFormatMode` and `ImportFormatOptions` parameters.

- **ImportFormatMode** options:
  - `UseDestinationStyles`: Apply destination document’s styles.
  - `KeepSourceFormatting`: Preserve source formatting.
  - `KeepDifferentStyles`: Keep both source and destination styles where possible.

- **ImportFormatOptions** options include:
  - `get_IgnoreHeaderFooter()`: Skip headers/footers.
  - `get_IgnoreTextBoxes()`: Skip text boxes.
  - `get_KeepSourceNumbering()`: Preserve source numbering.
  - `get_MergePastedLists()`: Merge pasted lists with existing ones.
  - `get_SmartStyleBehavior()`: Apply smart style behavior.

You can control section breaks and page setup using `Section::get_PageSetup()` properties (e.g., `SectionStart`, `RestartPageNumbering`) to affect how content appears after insertion/appending.

```cpp
System::SharedPtr<Aspose::Words::Document> srcDoc = System::MakeObject<Aspose::Words::Document>(u"Source.docx");
System::SharedPtr<Aspose::Words::Document> dstDoc = System::MakeObject<Aspose::Words::Document>(u"Destination.docx");

// Ensure source content starts on a new page
srcDoc->get_FirstSection()->get_PageSetup()->set_SectionStart(Aspose::Words::SectionStart::NewPage);

dstDoc->AppendDocument(srcDoc, Aspose::Words::ImportFormatMode::KeepSourceFormatting);
dstDoc->Save(u"Output.docx");
```

---