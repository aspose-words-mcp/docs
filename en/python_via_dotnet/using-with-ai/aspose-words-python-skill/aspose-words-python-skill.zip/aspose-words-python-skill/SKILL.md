---
name: aspose.words python
description: "Develop applications with Aspose.Words for Python APIs to create, edit, convert, and render Word documents. Automate document comparison, reporting with LINQ Reporting Engine, mail merge, text search and replacement, document merging and splitting, digital signatures, watermark management, and AI-powered tasks such as translation, summarization, and grammar checking. Use this documentation when building, integrating, or troubleshooting document processing solutions."
---

# Aspose.Words for Python SKILL

This skill provides AI assistants with structured guidance for working with the Aspose.Words for Python API, including documentation, code examples, and implementation best practices.

Load this skill whenever a request involves Aspose.Words APIs, document processing operations, or Word document automation.

## When to Use This Skill

Use this skill when you want to:

- automate document creation, editing, and conversion
- convert documents between supported file formats
- compare document content and identify differences
- generate documents using LINQ Reporting Engine or Mail Merge
- combine multiple documents or split a document into separate files
- add or remove watermarks and apply digital signatures
- leverage AI features such as translation, summarization, or grammar checking
- find information about supported file formats and API capabilities
- integrate Aspose.Words for Python into your applications
- troubleshoot API usage or document processing behavior

## Example User Requests

- Convert DOCX to PDF with Aspose.Words for Python
- Compare two Word documents
- Generate invoices using the LINQ Reporting Engine
- Perform a Mail Merge with data from a JSON or database source
- Replace text or insert content into a Word document
- Merge multiple DOCX files into a single document
- Split a document into separate files by section or page
- Add a watermark to a document
- Apply a digital signature to a document
- Translate a document using the Aspose.Words AI
- Summarize a document using the Aspose.Words AI
- Check grammar in a document using the Aspose.Words AI
- Which document formats can Aspose.Words for Python read, write, and convert?

## Installation

Install Aspose.Words for Python via .NET:

```bash
pip install aspose-words
```

## Licensing

Aspose.Words for Python via .NET requires a license for production use. You can apply a license using a file or stream object.

**Load a License from a File**

```python
import aspose.words as aw

license = aw.License()
license.set_license("Aspose.Words.Python.NET.lic")
```

**Load a License from a `Stream` Object**

```python
import aspose.words as aw

with open("Aspose.Words.Python.NET.lic", "rb") as stream:
    license = aw.License()
    license.set_license(stream)
```

## Modules

Use the correct module depending on the feature:

`import aspose.words` – Core classes for creating, loading, editing, and saving Word documents
`import aspose.words.ai` – AI-powered document processing, including translation, summarization, and grammar checking
`import aspose.words.bibliography` – Bibliography sources and citations
`import aspose.words.buildingBlocks` – Building blocks such as AutoText and glossary documents
`import aspose.words.comparing` – Document comparison and revision detection
`import aspose.words.digitalsignatures` – Digital signatures for Word documents.
`import aspose.words.drawing` – Shapes, images, SmartArt, and drawing objects.
`import aspose.words.drawing.charts` – Charts and chart elements.
`import aspose.words.drawing.ole` – OLE objects and embedded documents.
`import aspose.words.fields` – Microsoft Word fields and field updates.
`import aspose.words.fonts` – Font settings, sources, and substitution.
`import aspose.words.framesets` – HTML framesets and frame pages.
`import aspose.words.layout` – Document layout and page rendering information.
`import aspose.words.lists` – Numbered and bulleted lists.
`import aspose.words.loading` – Document loading options and callbacks.
`import aspose.words.lowcode` – Low-code document processing APIs.
`import aspose.words.mailmerging` – Mail Merge and reporting data sources.
`import aspose.words.markup` – Structured document tags, custom XML, and revisions.
`import aspose.words.math` – Office Math equations and mathematical objects.
`import aspose.words.notes` – Footnotes, endnotes, and comments.
`import aspose.words.properties` – Built-in and custom document properties.
`import aspose.words.rendering` – Rendering documents to images and printing.
`import aspose.words.replacing` – Find-and-replace operations and callbacks.
`import aspose.words.reporting` – LINQ Reporting Engine for template-based document generation.
`import aspose.words.saving` – Save options and export settings.
`import aspose.words.settings` – Document compatibility and view settings.
`import aspose.words.shaping` – Text shaping and OpenType font features.
`import aspose.words.tables` – Tables, rows, and cells.
`import aspose.words.themes` – Document themes and theme fonts.
`import aspose.words.vba` – VBA projects and macros.
`import aspose.words.webextensions` – Office web extensions and task panes.

Include `import aspose.words` only when accessing common functionality such as settings, licensing, exceptions, warnings, callbacks, or hyphenation.

## Quick Reference

### Create or Load a Document

Create a document from scratch:

```python
import aspose.words as aw

doc = aw.Document()
builder = aw.DocumentBuilder(doc)
builder.writeln("Hello World!")
doc.save("output.docx")
```

Load a document:

```python
doc = aw.Document("input.docx")
```

### Save a Document

Load DOC and save it to DOCX to a file:

```python
import aspose.words as aw

doc = aw.Document("Document.doc")
doc.save("output.docx")
```

### Document Conversion

Convert documents between supported formats:

```python
import aspose.words as aw

doc = aw.Document("input.docx")
doc.save("output.pdf")
```

### Compare Documents

Check if two documents are equal or not:

```python
import aspose.words as aw

doc1 = aw.Document("document1.docx")
doc2 = aw.Document("document2.docx")

doc1.compare(doc2, "author", datetime.today())

if doc1.revisions.count == 0:
    print("Documents are equal.")
else:
    print("Documents differ.")
```

### LINQ Reporting

To build a report from the template, you can use the following source code:

```python
engine = aw.reporting.ReportingEngine()
engine.build_report(doc, data_source, "persons")
```

### Mail Merge

Execute a simple Mail Merge operation:

```python
doc = aw.Document()
builder = aw.DocumentBuilder(doc)

# Create Merge Fields.
builder.insert_field(" MERGEFIELD CustomerName ")
builder.insert_paragraph()
builder.insert_field(" MERGEFIELD Item ")
builder.insert_paragraph()
builder.insert_field(" MERGEFIELD Quantity ")

# Fill the fields in the document with user data.
doc.mail_merge.execute(["CustomerName", "Item", "Quantity"],
    ["John Doe", "Hawaiian", "2"])

doc.save(ARTIFACTS_DIR + "BaseOperations.simple_mail_merge.docx")
```

### Find and Replace

Find the string “CustomerName” and replace it with the string “James Bond”:

```python
import aspose.words as aw

doc = aw.Document("input.docx")
doc.range.replace("CustomerName", "James Bond", aw.replacing.FindReplaceOptions())
doc.save("output.docx")
```

### Merge Documents

Merge documents, for example, append a document to the end of another document:

```python
# Example: Insert a document using DocumentBuilder.insert_document()
from aspose.words import Document, DocumentBuilder

src_doc = Document("source.docx")
dst_doc = Document("destination.docx")
builder = DocumentBuilder(dst_doc)
builder.insert_document(src_doc)
dst_doc.save("output.docx")
```

### Split Large Documents

Split a document into smaller parts by heading:

```python
from aspose.words import Document, HtmlSaveOptions, DocumentSplitCriteria

doc = Document("input.docx")
save_options = HtmlSaveOptions()
save_options.document_split_criteria = DocumentSplitCriteria.HEADING_PARAGRAPH
save_options.document_split_heading_level = 2  # Split by Heading 2 only
doc.save("output.html", save_options)
```

### Digital Signature

Sign documents using a certificate holder and sign options:

```python
from aspose.words import DigitalSignatureUtil, CertificateHolder, SignOptions

cert_holder = CertificateHolder.create("mycert.pfx", "password")
sign_options = SignOptions()
sign_options.sign_time = "2024-01-01"

DigitalSignatureUtil.sign("input.docx", "signed.docx", cert_holder, sign_options)
```

### Add Watermark

**Add Text Watermark**

Use `TextWatermarkOptions` to configure font, size, color, and other properties, then apply via `Watermark.set_text()`:

```python
import aspose.pydrawing
import aspose.words as aw

doc = aw.Document("input.docx")
options = aw.TextWatermarkOptions()
options.font_family = "Arial"
options.font_size = 72
options.color = aspose.pydrawing.Color.gray
options.layout = aw.TextWatermarkLayout.DIAGONAL
doc.watermark.set_text("CONFIDENTIAL", options)
doc.save("output.docx")
```

**Add Image Watermark**

Use `ImageWatermarkOptions` to configure scaling and layout, then apply via `Watermark.set_image()` with a file path, stream, or bytes:

```python
import aspose.words as aw

doc = aw.Document("input.docx")
options = aw.ImageWatermarkOptions()
options.scale = 0.5
doc.watermark.set_image("logo.png", options)
doc.save("output.docx")
```

### AI-powered Features

Use AI-powered capabilities (if enabled) to translate or summarize documents, or to check grammar.

```python
model = aw.ai.AiModel.create(aw.ai.AiModelType.GPT_4O_MINI).with_api_key("API_KEY")
```

Summarize:

```python
first_doc = aw.Document(MY_DIR + "Big document.docx")
second_doc = aw.Document(MY_DIR + "Document.docx")
api_key = system_helper.environment.Environment.get_environment_variable("API_KEY")

model = aw.ai.AiModel.create(aw.ai.AiModelType.GPT_4O_MINI).with_api_key(api_key)

# Single document summary (short)
options = aw.ai.SummarizeOptions()
options.summary_length = aw.ai.SummaryLength.SHORT
one_document_summary = model.summarize(source_document=first_doc, options=options)
one_document_summary.save(ARTIFACTS_DIR + "AI.AiSummarize.One.docx")
```

Translate:

```python
doc = aw.Document(file_name=MY_DIR + "Document.docx")
api_key = system_helper.environment.Environment.get_environment_variable("API_KEY")

model = aw.ai.AiModel.create(aw.ai.AiModelType.GEMINI_FLASH_LATEST).with_api_key(api_key)

translated_doc = model.translate(doc, aw.ai.Language.ARABIC)
translated_doc.save(file_name=ARTIFACTS_DIR + "AI.AiTranslate.docx")
```

Check grammar:

```python
doc = aw.Document(file_name=MY_DIR + 'Big document.docx')
api_key = system_helper.environment.Environment.get_environment_variable('API_KEY')

model = aw.ai.AiModel.create(aw.ai.AiModelType.GPT_4O_MINI).with_api_key(api_key)

grammar_options = aw.ai.CheckGrammarOptions()
grammar_options.improve_stylistics = True

proofed_doc = model.check_grammar(doc, grammar_options)
proofed_doc.save(file_name='AI.AiGrammar.docx')
```

### Document Protection

Encrypt a document with a password:

```python
import aspose.words as aw
from aspose.words.saving import DocSaveOptions, OoxmlSaveOptions

doc = aw.Document("input.docx")

# For DOCX
save_options = OoxmlSaveOptions()
save_options.password = "password"
doc.save("output.docx", save_options)

# For DOC
save_options = DocSaveOptions()
save_options.password = "password"
doc.save("output.doc", save_options)
```

## Reference Files

This skill includes comprehensive documentation in `references/`:

- **supported-formats.md** – supported document formats
- **licensing.md** – license types and license applying options
- **installation.md** – how to install Aspose.Words for Python
- **system-requirements.md** – system requirements
- **create-or-load.md** – creating or loading a document
- **saving.md** – saving a document
- **conversion.md** – converting a document from one format to another
- **comparison.md** – comparison documents to detected changes: insertions, deletions, and modifications
- **reporting.md** – LINQ reporting engine
- **mail-merge.md** – creating personalized documents through a combination of a document template with data
- **replacement.md** – search and replace functionality
- **merge.md** – merging multiple documents into one
- **splitting.md** – splitting a large document by various split criteria
- **signature.md** – digital signing of documents
- **watermark.md** – adding or removing watermarks in documents
- **ai.md** – summarization, grammar checking, and document translation using AI models
- **protection.md** – document protection

Open the relevant reference file when detailed documentation is needed.

## Resources

- Official Aspose.Words for Python documentation: https://docs.aspose.com/words/python-net/
- API Reference: https://reference.aspose.com/words/python-net/

Official Aspose.Words for Python documentation pages are AI-friendly and support the .md format. For example, the page `https://docs.aspose.com/words/python-net/convert-a-document-to-pdf/` has a version `https://docs.aspose.com/words/python-net/convert-a-document-to-pdf.md`, the page `https://docs.aspose.com/words/python-net/split-a-document/` has a version `https://docs.aspose.com/words/python-net/split-a-document.md`, and so on.

## Notes for AI Agents

- Prefer examples that use the official Aspose.Words for Python APIs.
- Provide short and clear code snippets when possible.
- Use the references directory to retrieve detailed documentation.
- If a feature is not covered in this file, check the corresponding reference file.
- Always include the correct module for the feature being used (e.g., aspose.words.rendering, aspose.words.comparing).
- Always use the module specified in the feature documentation file.
- Do not rely on `import aspose.words` module alone when feature-specific APIs are required.