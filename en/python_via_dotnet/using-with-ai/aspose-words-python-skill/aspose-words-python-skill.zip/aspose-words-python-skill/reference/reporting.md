# Aspose.Words for Python - Reporting

---
**URL:** https://docs.aspose.com/words/python-net/linq-reporting-engine.md

**Contents:**
- LINQ Reporting Engine Overview
- Building Reports
- Accessing XML Data
- Accessing JSON Data
- Accessing CSV Data
- Removing Empty Paragraphs
- Handling Missing Members
- Inlining Syntax Error Messages
- Optimizing Reflection Calls

---
title: "LINQ Reporting Engine"
---

**LINQ Reporting Engine Overview**

The LINQ Reporting Engine in Aspose.Words for Python via .NET enables report generation from template documents using LINQ-style expressions. All core features available in the .NET version are exposed to Python, including data binding, conditional sections, repeating sections, and custom functions. Template syntax is identical to the .NET implementation and documented in the [Aspose.Words for .NET documentation](/words/net/linq-reporting-engine/).

Classes of the LINQ Reporting Engine reside in the `aspose.words.reporting` module, with the main class being `ReportingEngine`.

**Building Reports**

To build a report, use one of the `ReportingEngine.build_report()` overloads:

| Parameter | Description |
| :-- | :-- |
| `document` | A template document that becomes the final report after data population. |
| `data_source` | A data source object of type `XmlDataSource`, `JsonDataSource`, or `CsvDataSource`. |
| `data_source_name` | Optional identifier for the data source used in the template (e.g., `<<foreach [in persons]>>`). |

Example:

```python
engine = aw.reporting.ReportingEngine()
engine.build_report(doc, data_source, "persons")
```

For more details, see the [LINQ Reporting Engine API](https://docs.aspose.com/words/python-net/linq-reporting-engine-api/) page.

---