# Aspose.Words for Python - Supported document formats

---
**URL:** https://docs.aspose.com/words/python-net/supported-document-formats.md

**Contents:**
- Supported Document Formats
- Loading Formats
- Saving Formats
- Image Export
- E-book Format Support

---
title: "Supported Document Formats"
---

**Supported Document Formats**

Aspose.Words for Python via .NET supports loading and saving a wide range of document, e-book, image, and page-description formats. The following table summarizes the supported input (Load) and output (Save) capabilities.

| Format | Description | Load | Save |
| :--- | :--- | :--- | :--- |
| DOC | Microsoft Word 97–2007 Document | ✅ | ✅ |
| DOT | Microsoft Word 97–2007 Template | ✅ | ✅ |
| DOC_PRE_WORD60 | Word 6 or Word 95 format | ✅ | — |
| DOCX | Office Open XML (macro-free) | ✅ | ✅ |
| DOCM | Office Open XML Macro-Enabled Document | ✅ | ✅ |
| DOTX | Office Open XML Template (macro-free) | ✅ | ✅ |
| DOTM | Office Open XML Macro-Enabled Template | ✅ | ✅ |
| FLAT_OPC | Flat XML OPC package | ✅ | ✅ |
| FLAT_OPC_MACRO_ENABLED | Flat XML macro-enabled document | ✅ | ✅ |
| FLAT_OPC_TEMPLATE | Flat XML template | ✅ | ✅ |
| FLAT_OPC_TEMPLATE_MACRO_ENABLED | Flat XML macro-enabled template | ✅ | ✅ |
| XML | XML document | ✅ | — |
| RTF | RTF format | ✅ | ✅ |
| WORD_ML | Word 2003 WordprocessingML | ✅ | ✅ |
| HTML | HTML/XHTML | ✅ | ✅ |
| MHTML | MHTML (Web archive) | ✅ | ✅ |
| MOBI | MOBI e-book | ✅ | ✅ |
| AZW3 | AZW3 e-book | ✅ | ✅ |
| CHM | Compiled HTML Help | ✅ | — |
| ODT | ODF Text Document | ✅ | ✅ |
| OTT | ODF Text Template | ✅ | ✅ |
| TXT | Plain text | ✅ | ✅ |
| MD | Markdown | ✅ | ✅ |
| PDF | PDF | ✅ | ✅ |
| XLSX | Spreadsheet (read-only) | — | ✅ |
| EPS | Encapsulated PostScript | — | ✅ |
| XPS | XML Paper Specification | — | ✅ |
| XAML_FIXED | Fixed XAML document | — | ✅ |
| SVG | Scalable Vector Graphics | — | ✅ |
| HTML_FIXED | Fixed-position HTML | — | ✅ |
| OPEN_XPS | OpenXPS format | — | ✅ |
| PS | PostScript | — | ✅ |
| PCL | Printer Control Language | — | ✅ |
| EPUB | EPUB e-book | ✅ | ✅ |
| XAML_FLOW | Flow XAML (beta) | — | ✅ |
| XAML_FLOW_PACK | Flow XAML package (beta) | — | ✅ |
| DOCLING | Docling JSON | — | ✅ |
| TIFF | Multi-page TIFF image | — | ✅ |
| PNG | PNG image | — | ✅ |
| BMP | BMP image | — | ✅ |
| EMF | Enhanced Metafile (vector) | — | ✅ |
| JPEG | JPEG image | — | ✅ |
| GIF | GIF image | — | ✅ |
| WebP | WebP image | — | ✅ |

---