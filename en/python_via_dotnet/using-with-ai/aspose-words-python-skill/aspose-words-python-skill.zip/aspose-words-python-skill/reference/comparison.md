# Aspose.Words for Python - Comparison

---
**URL:** https://docs.aspose.com/words/python-net/compare-documents.md

**Contents:**
- Compare Two Documents
- Specify Advanced Comparison Options

---
title: "Compare Documents"
---

**Compare Two Documents**

The `Document.compare` method identifies differences between two documents and records them as revisions in the first (original) document. The comparison works at word or character level: if any character in a word changes, the entire word is marked as changed.

Documents are considered *equal* only if no revisions are generated — meaning identical text and formatting. However, some differences (e.g., style definitions) may remain undetected due to Microsoft Word limitations.

```python
import aspose.words as aw

doc1 = aw.Document("document1.docx")
doc2 = aw.Document("document2.docx")

doc1.compare(doc2, "author", datetime.today())

if doc1.revisions.count == 0:
    print("Documents are equal.")
else:
    print("Documents differ.")
```

**Limitations:**
- Neither document may contain existing revisions before comparison
- Comparison is supported for all [document formats](/words/python-net/supported-document-formats/) supported by Aspose.Words

**Specify Advanced Comparison Options**

Use the `CompareOptions` class to customize comparison behavior:

- `ignore_headers_and_footers`: Skip header/footer differences
- `ignore_formatting`: Ignore formatting changes (font, spacing, etc.)
- `ignore_comments`, `ignore_textboxes`, `ignore_footnotes`: Skip specific content types
- `granularity`: Set to `Granularity.WORD_LEVEL` (default) or `Granularity.CHAR_LEVEL`
- `target`: Determine which document shows changes (`ORIGINAL`, `CURRENT`, or `NONE`)

```python
import aspose.words as aw
import aspose.words.comparing as awc
from datetime import datetime

doc1 = aw.Document("source.docx")
doc2 = aw.Document("target.docx")

options = awc.CompareOptions()
options.ignore_headers_and_footers = True
options.ignore_formatting = False
options.granularity = awc.Granularity.CHAR_LEVEL
options.target = awc.Target.CURRENT

doc1.compare(doc2, "author", datetime.today(), options)
```

---