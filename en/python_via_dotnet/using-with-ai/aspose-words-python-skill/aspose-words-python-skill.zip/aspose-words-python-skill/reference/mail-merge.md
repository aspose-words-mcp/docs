# Aspose.Words for Python - Mail Merge

---
**URL:** https://docs.aspose.com/words/python-net/mail-merge-and-reporting.md

**Contents:**
- Mail Merge and Reporting Overview
- Mail Merge Template
- Merged Documents
- Types of Mail Merge Operation
- Advanced Mail Merge Features
- Clean Up Before or During Mail Merge
- Insert Checkboxes, Text Input, or Images during Mail Merge
- Mail Merge Template from Mustache Syntax

---
title: "Mail Merge and Reporting in Python"
---

**Mail Merge and Reporting Overview**  
Aspose.Words for Python via .NET provides a robust mail merge and reporting solution that extends beyond basic field replacement to support complex documents such as reports, catalogs, inventories, and invoices.

Key capabilities include:
- Designing reports in Microsoft Word using standard Mail Merge fields
- Defining dynamic regions (e.g., repeating order rows)
- Inserting images during merge
- Executing custom logic via event handlers
- Supporting any data source type through custom implementations

The `aspose.words.mailmerging` module provides the core functionality.

**Mail Merge Template**  
A Mail Merge template is a document (e.g., DOCX, RTF) containing fixed content and merge fields (e.g., `MERGEFIELD FirstName`). Templates can be created manually in Word or programmatically using `DocumentBuilder`.

To create a template programmatically:
```python
import aspose.words as aw

doc = aw.Document()
builder = aw.DocumentBuilder(doc)
builder.write("Dear ")
builder.insert_field("MERGEFIELD FirstName \\* MERGEFORMAT")
builder.write(",")
builder.insert_paragraph()
builder.write("Thank you for your order.")
doc.save("Template.docx")
```

Merge regions (for repeating data) are defined using `<<TableStart:Name>>` and `<<TableEnd:Name>>` fields:
```python
builder.insert_field("MERGEFIELD TableStart:Items \\* MERGEFORMAT")
# ... table rows with fields ...
builder.insert_field("MERGEFIELD TableEnd:Items \\* MERGEFORMAT")
```

**Merged Documents**  
A merged document is the output of combining a template with a data source. All merge fields are replaced with actual data.

Example of executing a simple merge:

```python
doc = aw.Document("Template.docx")
field_names = ["FirstName", "LastName"]
values = ["John", "Doe"]
doc.mail_merge.execute(field_names, values)
doc.save("Result.docx")
```

**Types of Mail Merge Operation**  
Two types are supported:

1. **Simple Mail Merge**  
   Fills merge fields across the entire document and repeats the full document for each record. Use when no regions are defined.

   ```python
   doc.mail_merge.execute(["Name", "Address"], ["Alice", "123 Main St"])
   ```

2. **Mail Merge with Regions**  
   Repeats only designated regions (`<<TableStart:Name>>` to `<<TableEnd:Name>>`) per record. Ideal for tabular data.

   ```python
   # Custom data source implementing IMailMergeDataSource
   class OrdersDataSource(aw.mailmerging.IMailMergeDataSource):
       def __init__(self, orders):
           self._orders = orders
           self._index = -1
           self._table_name = "Orders"

       def get_column_names(self):
           return ["OrderID", "Amount"]

       def get_field(self, field_name, value):
           if field_name == "OrderID":
               value.value = str(self._orders[self._index]["id"])
           elif field_name == "Amount":
               value.value = str(self._orders[self._index]["amount"])
           return True

       def move_next(self):
           self._index += 1
           return self._index < len(self._orders)

       @property
       def table_name(self):
           return self._table_name

   orders = [{"id": 1, "amount": 99.99}, {"id": 2, "amount": 149.50}]
   doc.mail_merge.execute_with_regions(OrdersDataSource(orders))
   ```

   Nested regions are supported via `get_child_data_source`.

**Advanced Mail Merge Features**  
- **Template Inspection**  
  Retrieve merge field names and region hierarchy:

  ```python
  field_names = doc.mail_merge.get_field_names()
  region_info = doc.mail_merge.get_regions_hierarchy()
  ```

- **Data Mapping**  
  Map data source columns to differently named merge fields:

  ```python
  doc.mail_merge.mapped_data_fields.add("MergeName", "DB_Name")
  ```

- **Merge Rules**  
  Use `NextIf` and `SkipIf` fields to conditionally control record flow:

  ```python
  # In template: { NEXTIF { MERGEFIELD Status } = "Active" }
  # Skips to next record only if condition is true
  ```

**Clean Up Before or During Mail Merge**  
Configure cleanup behavior via `cleanup_options` (of type `MailMergeCleanupOptions`):

```python
doc.mail_merge.cleanup_options = (
    aw.mailmerging.MailMergeCleanupOptions.REMOVE_EMPTY_PARAGRAPHS |
    aw.mailmerging.MailMergeCleanupOptions.REMOVE_UNUSED_REGIONS |
    aw.mailmerging.MailMergeCleanupOptions.REMOVE_EMPTY_TABLE_ROWS
)
```

Available options:
- `REMOVE_EMPTY_PARAGRAPHS`: Deletes paragraphs left empty after field removal
- `REMOVE_UNUSED_REGIONS`: Removes regions not matched by data source
- `REMOVE_UNUSED_FIELDS`: Removes fields without corresponding data
- `REMOVE_CONTAINING_FIELDS`: Removes outer fields (e.g., `IF`) when inner field is merged/removed
- `REMOVE_EMPTY_TABLE_ROWS`: Deletes table rows with empty merge fields

Note: Cleanup options apply only after the final `execute`/`execute_with_regions` call.

**Insert Checkboxes, Text Input, or Images during Mail Merge**

Use the `field_merging_callback` event to customize field replacement:

- **Form Fields (Checkboxes, Text Input)**

  ```python
  class MyHandler(aw.mailmerging.IMailMergeCallback):
      def field_merging(self, e):
          if e.field_name == "Agree":
              # Insert checkbox
              builder = aw.DocumentBuilder(e.document)
              builder.move_to_merge_field(e.field_name)
              builder.insert_checkbox("AgreeBox", True, 0)
              e.text = ""
          elif e.field_name == "Notes":
              # Insert text input
              builder = aw.DocumentBuilder(e.document)
              builder.move_to_merge_field(e.field_name)
              builder.insert_text_input("TextInput", aw.fields.TextFormFieldType.REGULAR, "", e.field_value, 0)
              e.text = ""

  doc.mail_merge.field_merging_callback = MyHandler()
  ```

- **Images**

  Use `Image:FieldName` merge fields and handle `image_field_merging`:
  ```python
  class ImageHandler(aw.mailmerging.IMailMergeCallback):
      def image_field_merging(self, e):
          args = e  # ImageFieldMergingArgs
          if args.field_name == "Logo":
              args.image_file_name = "logo.png"
              args.image_width = 100
              args.image_height = 50
          elif args.field_name == "Photo":
              # Load from stream
              args.image_stream = open("photo.jpg", "rb")

  doc.mail_merge.field_merging_callback = ImageHandler()
  ```

**Mail Merge Template from Mustache Syntax**  

Mustache syntax (`{{FieldName}}`) is an alternative to merge fields, especially useful for HTML/TXT templates or when avoiding fields.

Enable Mustache support:
```python
doc = aw.Document("Template.docx")
doc.mail_merge.use_non_merge_fields = True
doc.mail_merge.execute(["FirstName", "LastName"], ["Jane", "Smith"])
```

Mustache supports `{{#foreach}}` for regions (alternative to `TableStart/TableEnd`):
```mustache
{{#Orders}}
  Order ID: {{OrderID}}, Amount: {{Amount}}
{{/Orders}}
```

Combine with `IF` fields for conditional logic:
```mustache
{ IF "{{Gender}}" = "MALE" "His" "Her" }
```

Mustache tags are processed only when `use_non_merge_fields = True`.

---