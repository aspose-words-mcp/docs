# Aspose.Words for Python - Licensing and Subscription

---
**URL:** https://docs.aspose.com/words/python-net/licensing.md

**Contents:**
- Free Trial or Temporary License
- Purchased License
- License Applying Options
- Changing the License File Name
- “Cannot find license filename” Exception
- Using Multiple Aspose Products

---
title: "Licensing and Subscription"
---

**Free Trial or Temporary License**

The evaluation version of Aspose.Words for Python via .NET provides full product functionality but inserts an evaluative watermark at the top of the document upon loading and saving and limits the maximum document size to a few hundred paragraphs. The trial version becomes licensed when a license is applied.

Alternatively, a 30-day Temporary License can be requested to test the product without trial limitations. For more details, see the [Get a Temporary License](https://purchase.aspose.com/temporary-license/) page.

**Purchased License**

After purchase, the license must be applied using the `set_license()` method before using any other Aspose.Words classes. It only needs to be set once per application domain.

Pricing information is available on the [Pricing Information](https://purchase.aspose.com/pricing/words/family/) page.

**License Applying Options**

Licenses can be applied from:

- An explicit file path  
- The folder containing the Python script calling Aspose.Words  
- A `Stream` object  
- Metered keys (for metered licensing)

Calling `set_license()` or `set_metered_key()` multiple times is harmless but inefficient.

**Load a License from a File**

```python
import aspose.words as aw

license = aw.License()
license.set_license("Aspose.Words.Python.NET.lic")
```

**Load a License from a `Stream` Object**

```python
import aspose.words as aw

with open("Aspose.Words.Python.NET.lic", "rb") as stream:
    license = aw.License()
    license.set_license(stream)
```

**Apply Metered License**

Metered licensing allows billing based on API usage. After obtaining public and private keys, apply them once at application startup:

```python
import aspose.words as aw

metered = aw.Metered()
metered.set_metered_key("public_key", "private_key")
```

A stable Internet connection is required. If connectivity is lost for more than 24 hours, the library reverts to evaluation mode. Use `is_metered_licensed()` to check the status and reapply the key if needed.

**Changing the License File Name**

The license file can be renamed as desired. Use the new name when calling `set_license()`.

**“Cannot find license filename” Exception**

Some browsers append `.xml` to the license file (e.g., `Aspose.Words.Python.NET.lic.XML`). Windows may hide this extension, causing a mismatch. Rename the file to remove `.xml` or disable “hide extensions” in Explorer.

**Using Multiple Aspose Products**

- Set the license separately for each Aspose product using its respective `License` class (e.g., `aspose.words.License`, `aspose.cells.License`).
- Use fully qualified class names to avoid confusion.

---