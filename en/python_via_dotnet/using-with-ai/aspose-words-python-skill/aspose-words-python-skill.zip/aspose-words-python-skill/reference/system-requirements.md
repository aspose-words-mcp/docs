# Aspose.Words for Python - System requirements

---
**URL:** https://docs.aspose.com/words/python-net/system-requirements.md

**Contents:**
- Supported Operating Systems
- System Requirements for Target Linux and macOS Platforms

---
title: "System Requirements"
---

**Supported Operating Systems**

Aspose.Words for Python via .NET supports any 64-bit or 32-bit operating system where Python 3.5 or later is installed.

| Operating System | Supported Versions |
|------------------|--------------------|
| Microsoft Windows | Windows 2003 Server (x64, x86), Windows 2008 Server (x64, x86), Windows 2012 Server (x64, x86), Windows 2012 R2 Server (x64, x86), Windows 2016 Server (x64, x86), Windows 2019 Server (x64, x86), Windows XP (x64, x86), Windows Vista (x64, x86), Windows 7 (x64, x86), Windows 8/8.1 (x64, x86), Windows 10 (x64, x86) |
| macOS | macOS-x86_64: 10.14 or later; macOS-arm64: 11.0 or later |
| Linux | Ubuntu, OpenSUSE, CentOS, and other distributions |

**System Requirements for Target Linux and macOS Platforms**

- GCC-6 runtime libraries (or later).
- Native dependencies of .NET Core Runtime (installing .NET Core Runtime itself is *not* required).
- For Python 3.5–3.7:
  - The `pymalloc` build of Python is required (enabled by default with `--with-pymalloc`; typically marked with `m` suffix in filename).
  - The `libpython` shared library must be available (e.g., `libpython3.7m.so.1.0` for Python 3.5–3.7, `libpython3.9.so.1.0` for Python 3.8+).
    - Install via package manager (e.g., `sudo apt-get install libpython3.7`).
    - If installed in a non-standard location, create a symbolic link to the standard shared library path.

> **Note:** The Aspose.Words for Python via .NET package bundles the necessary .NET Core runtime components; no separate installation of .NET Core Runtime is needed.

Supported Linux configurations are documented in the [Aspose.Words-for-Python-via-.NET/Dockerfile](https://github.com/aspose-words/Aspose.Words-for-Python-via-.NET/blob/master/Dockerfile).

---