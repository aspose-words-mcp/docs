# Aspose.Words for Python - Save a Document

---
**URL:** https://docs.aspose.com/words/python-net/save-a-document.md

**Contents:**
- Save a Document to a File
- Save a Document to a Stream
- Send a Document to a Client Browser
- Specify Save Options

---
title: "Save a Document in Python"
---

**Save a Document to a File**

Use the `save` method of the `Document` class with a file name. Aspose.Words determines the save format from the file extension.

```python
import aspose.words as aw

doc = aw.Document("Document.docx")
doc.save("output.docx")
```

**Save a Document to a Stream**

Pass a stream object to the `save` method and explicitly specify the save format using `SaveFormat`.

```python
import io
import aspose.words as aw

doc = aw.Document("Document.docx")

stream = io.BytesIO()
doc.save(stream, aw.SaveFormat.DOCX)
data = stream.getvalue()
```

**Send a Document to a Client Browser**

Save the document to an in-memory stream and return it via your web framework’s response. Use the `Content-Disposition` header to control presentation (`attachment` for download, `inline` for inline display).

```python
import io
import aspose.words as aw
from flask import Response

doc = aw.Document("Document.docx")
stream = io.BytesIO()
doc.save(stream, aw.SaveFormat.DOCX)
data = stream.getvalue()

return Response(
    data,
    mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    headers={"Content-Disposition": "attachment; filename=Document.docx"})
```

**Specify Save Options**

When saving a document, you can set some advanced properties. Aspose.Words provides you with the [SaveOptions](https://reference.aspose.com/words/python-net/aspose.words.saving/saveoptions/) class, which allows more precise control of the save process. There are overloads of the **Save** method that accept a **SaveOptions** object – it should be an object of a class derived from the **SaveOptions** class.

Each save format has a corresponding class that holds save options for this save format, for example, there is [PdfSaveOptions](https://reference.aspose.com/words/python-net/aspose.words.saving/pdfsaveoptions/) for saving to PDF format, [MarkdownSaveOptions](https://reference.aspose.com/words/python-net/aspose.words.saving/markdownsaveoptions/) for saving to Markdown format, or [ImageSaveOptions](https://reference.aspose.com/words/python-net/aspose.words.saving/imagesaveoptions/) for saving to an image.

Update the document creation time:

```python
doc = aw.Document(MY_DIR + "Rendering.docx")

save_options = aw.saving.PdfSaveOptions()
save_options.update_last_printed_property = True

doc.save(ARTIFACTS_DIR + "WorkingWithPdfSaveOptions.update_if_last_printed.pdf", save_options)
```

---