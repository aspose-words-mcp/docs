# Aspose.Words for Python - Document Protection and Encryption

---
**URL:** https://docs.aspose.com/words/python-net/protect-or-encrypt-a-document.md

**Contents:**
- Document Protection Options
- Read-Only Protection
- Encryption
- Restrict Document Editing
- Digital Signatures

---
title: "Protect or Encrypt a Document"
---

**Document Protection Options**

Aspose.Words for Python via .NET supports the following document protection features:

| Feature | Description | Corresponding MS Word feature |
|---------|-------------|-------------------------------|
| Read-Only | Prevents modification of document content | Always Open Read-Only, Password to modify |
| Encrypt a Document | Secures document with password encryption | Encrypt with Password, Password to open |
| Restrict Editing | Allows fine-grained control over editing permissions | Restrict Editing |
| Digital Signatures | Authenticates document origin and integrity | Add a Digital Signature |

Note: Aspose.Words does not support Microsoft Word features "Mark as Final" and "Restrict Access".

**Read-Only Protection**

To make a document read-only, use the `WriteProtection` class accessible via `document.write_protection`:

- Set a password using `set_password(password)` to protect the read-only setting
- Enable read-only recommendation with `read_only_recommended = True`
- Enforce read-only mode with `protect(ProtectionType.READ_ONLY)`

The `is_write_protected` property checks if a password is set.

```python
import aspose.words as aw

doc = aw.Document("input.docx")
doc.write_protection.set_password("password")
doc.write_protection.read_only_recommended = True
doc.protect(aw.ProtectionType.READ_ONLY)
doc.save("output.docx")
```

To remove read-only protection:

```python
doc.write_protection.read_only_recommended = False
doc.protect(aw.ProtectionType.NO_PROTECTION)
```

**Encryption**

Encryption secures document content by encoding it with a password. Only specific formats support encryption:

| Format | Encryption while Loading | Encryption while Saving |
|--------|--------------------------|------------------------|
| DOC, DOT | XOR, 40-bit RC4, CryptoAPI RC4 | RC4 (40-bit) |
| DOCX, DOTX, DOCM, DOTM, FlatOPC | ECMA-376 Standard, ECMA-376 Agile | ECMA-376 Standard (AES128 + SHA1) |
| ODT, OTT | ODF Encryption (Blowfish/AES) | ODF Encryption (AES256 + SHA256) |
| PDF | - | AES-128 / AES-256 |

Use format-specific save options to set encryption:

```python
import aspose.words as aw
from aspose.words.saving import DocSaveOptions, OoxmlSaveOptions

doc = aw.Document("input.docx")

# For DOCX
save_options = OoxmlSaveOptions()
save_options.password = "password"
doc.save("output.docx", save_options)

# For DOC
save_options = DocSaveOptions()
save_options.password = "password"
doc.save("output.doc", save_options)
```

Check if a document is encrypted before loading:

```python
from aspose.words import FileFormatUtil

info = FileFormatUtil.detect_file_format("document.docx")
if info.is_encrypted:
    # Prompt for password
    pass
```

Load encrypted documents with password:

```python
load_options = aw.loading.LoadOptions()
load_options.password = "password"
doc = aw.Document("encrypted.docx", load_options)
```

**Restrict Document Editing**

Use `ProtectionType` enumeration to specify editing restrictions:

- `READ_ONLY` – No editing allowed
- `ALLOW_ONLY_COMMENTS` – Only comments
- `ALLOW_ONLY_FORM_FIELDS` – Only form fields
- `ALLOW_ONLY_REVISIONS` – Only revision tracking
- `NO_PROTECTION` – No restrictions

Apply protection with `protect()`:

```python
import aspose.words as aw

doc = aw.Document("input.docx")
doc.protect(aw.ProtectionType.ALLOW_ONLY_FORM_FIELDS, "password")
doc.save("output.docx")
```

Remove protection:

```python
doc.unprotect()  # Works with or without password
```

Define unrestricted editable regions:

```python
doc = aw.Document()
builder = aw.DocumentBuilder(doc)

# Make entire document read-only
doc.protect(aw.ProtectionType.READ_ONLY, "password")

# Make specific region editable
builder.start_editable_range()
builder.writeln("This text can be edited.")
builder.end_editable_range()
```

**Digital Signatures**

Use `DigitalSignatureUtil` class to work with digital signatures:

Detect signatures:

```python
from aspose.words import FileFormatUtil

info = FileFormatUtil.detect_file_format("document.docx")
has_sig = info.has_digital_signature
```

Verify signatures:

```python
from aspose.words.digitalsignatures import DigitalSignatureUtil

signatures = DigitalSignatureUtil.load_signatures("document.docx")
for sig in signatures:
    is_valid = sig.is_valid
```

Sign a document:

```python
from aspose.words.digitalsignatures import CertificateHolder, DigitalSignatureUtil, SignOptions

cert_holder = CertificateHolder.create("certificate.pfx", "password")
sign_options = SignOptions()
sign_options.sign_time = datetime.now()

DigitalSignatureUtil.sign("input.docx", "output.docx", cert_holder, sign_options)
```

Remove all signatures:

```python
DigitalSignatureUtil.remove_all_signatures("signed.docx", "unsigned.docx")
```

More examples are in a separate *signature.md* file.

---