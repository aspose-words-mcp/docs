# Aspose.Words for Python - Merge Documents

---
**URL:** https://docs.aspose.com/words/python-net/insert-and-append-documents.md

**Contents:**
- Insert a Document
- Insert a Document During Find and Replace Operation
- Insert a Document During Mail Merge Operation
- Insert a Document at Bookmark
- Append a Document
- Import and Insert Nodes Manually
- Common Properties for Insert and Append Documents

---
title: "Insert and Append Documents"
---

**Insert a Document**

Aspose.Words represents a document as a tree of nodes. Inserting one document into another involves copying nodes from the source document tree to the destination.

You can insert a document at the current cursor position using `DocumentBuilder.insert_document()` or `DocumentBuilder.insert_document_inline()`.

```python
# Example: Insert a document using DocumentBuilder.insert_document()
from aspose.words import Document, DocumentBuilder

src_doc = Document("source.docx")
dst_doc = Document("destination.docx")
builder = DocumentBuilder(dst_doc)
builder.insert_document(src_doc)
dst_doc.save("output.docx")
```

```python
# Example: Insert a document inline using DocumentBuilder.insert_document_inline()
from aspose.words import Document, DocumentBuilder, ImportFormatMode

src_doc = Document("source.docx")
dst_doc = Document("destination.docx")
builder = DocumentBuilder(dst_doc)
builder.insert_document_inline(src_doc, ImportFormatMode.KEEP_SOURCE_FORMATTING)
dst_doc.save("output.docx")
```

**Insert a Document During Find and Replace Operation**

You can insert content dynamically during a find-and-replace operation by handling the `Replacing` event.

```python
# Example: Insert document content during find and replace
from aspose.words import Document, ReplacingArgs
import aspose.words as aw

def insert_document_on_replace(sender, e):
    # Load the document to insert
    insert_doc = Document("insert_me.docx")
    # Insert at the match position
    builder = aw.DocumentBuilder(e.match_node.parent_node.document)
    builder.move_to(e.match_node)
    builder.insert_document(insert_doc, aw.ImportFormatMode.USE_DESTINATION_STYLES)

doc = Document("template.docx")
doc.replace("[INTRODUCTION]", "", insert_document_on_replace)
doc.save("output.docx")
```

**Insert a Document During Mail Merge Operation**

You can insert a document into a merge field by handling the `MergeField` event.

```python
# Example: Insert document content during mail merge
from aspose.words import Document, MergeFieldEventArgs
import aspose.words as aw

def insert_document_on_merge_field(sender, e):
    if e.field_name == "Summary":
        insert_doc = Document("summary.docx")
        builder = aw.DocumentBuilder(e.field.document)
        builder.move_to(e.field)
        builder.insert_document(insert_doc, aw.ImportFormatMode.KEEP_SOURCE_FORMATTING)

doc = Document("mail_merge_template.docx")
doc.merge_field_handlers = [insert_document_on_merge_field]
doc.execute_merge(["Summary"], [None])  # value ignored due to handler
doc.save("output.docx")
```

**Insert a Document at Bookmark**

You can insert a document at a bookmark location. The bookmark should be placed in an empty paragraph to avoid moving surrounding content.

```python
# Example: Insert document at bookmark
from aspose.words import Document, Bookmark

src_doc = Document("source.docx")
dst_doc = Document("destination.docx")
bookmark = dst_doc.range.bookmarks["InsertHere"]
dst_doc.builder.move_to_bookmark("InsertHere")
dst_doc.builder.insert_document(src_doc)
dst_doc.save("output.docx")
```

**Append a Document**

Use `Document.append_document()` to add a document at the end of another.

```python
# Example: Append document to the end
from aspose.words import Document, ImportFormatMode

src_doc = Document("source.docx")
dst_doc = Document("destination.docx")
dst_doc.append_document(src_doc, ImportFormatMode.KEEP_SOURCE_FORMATTING)
dst_doc.save("output.docx")
```

**Import and Insert Nodes Manually**

To insert specific nodes (e.g., sections, paragraphs), import them first using `Document.import_node()`, then insert using `insert_after()`, `insert_before()`, or `append_child()`.

```python
# Example: Import and insert a paragraph
from aspose.words import Document

src_doc = Document("source.docx")
dst_doc = Document("destination.docx")

# Import the first paragraph from source
src_paragraph = src_doc.first_section.body.first_paragraph
imported_paragraph = dst_doc.import_node(src_paragraph, True)

# Insert after the last paragraph in destination
last_paragraph = dst_doc.first_section.body.last_paragraph
last_paragraph.parent_node.insert_after(imported_paragraph, last_paragraph)

dst_doc.save("output.docx")
```

**Common Properties for Insert and Append Documents**

Both `insert_document()` and `append_document()` accept `ImportFormatMode` and `ImportFormatOptions`:

- `ImportFormatMode`:
  - `USE_DESTINATION_STYLES`: Apply destination styles.
  - `KEEP_SOURCE_FORMATTING`: Preserve source formatting.
  - `KEEP_DIFFERENT_STYLES`: Keep both if styles differ.

- `ImportFormatOptions`:
  - `ignore_header_footer`: Skip headers/footers.
  - `ignore_text_boxes`: Skip text boxes.
  - `keep_source_numbering`: Preserve list numbering.
  - `merge_pasted_lists`: Merge lists with destination.
  - `smart_style_behavior`: Resolve style conflicts intelligently.

You can control section behavior (e.g., page breaks) using `SectionStart` and `PageSetup`.

```python
# Example: Append document with new section start
from aspose.words import Document, ImportFormatMode, SectionStart

src_doc = Document("source.docx")
dst_doc = Document("destination.docx")

# Ensure source sections start on new page
for section in src_doc.sections:
    section.page_setup.section_start = SectionStart.NEW_PAGE

dst_doc.append_document(src_doc, ImportFormatMode.KEEP_SOURCE_FORMATTING)
dst_doc.save("output.docx")
```

---