# Aspose.Words for Python - Split Large Documents

---
**URL:** https://docs.aspose.com/words/python-net/split-a-document.md

**Contents:**
- Split a Document Using Different Criteria
- Split a Document by Headings
- Split a Document by Sections
- Split by Pages
- Callback Option to Save a Document
- Merge the Split Document with Another Document

---
title: "Split a Document"
---

**Split a Document Using Different Criteria**

Aspose.Words for Python via .NET allows splitting EPUB or HTML documents into chapters using various criteria defined by the `DocumentSplitCriteria` enumeration. Supported criteria include:

- `HEADING_PARAGRAPH`
- `SECTION_BREAK`
- `COLUMN_BREAK`
- `PAGE_BREAK`

Multiple criteria can be combined. When saving to HTML, each chapter becomes a separate HTML file. For EPUB, the output is a single file, but the internal structure reflects the split for reader applications.

> **Note:** Splitting via `document_split_criteria` is not supported for MHTML.

**Split a Document by Headings**

To split a document by heading paragraphs, set `document_split_criteria` to `HEADING_PARAGRAPH`. To split by a specific heading level (e.g., Heading 2 only), also set `document_split_heading_level`.

Only HTML output supports splitting by headings. For EPUB, the document remains a single file.

```python
from aspose.words import Document, HtmlSaveOptions, DocumentSplitCriteria

doc = Document("input.docx")
save_options = HtmlSaveOptions()
save_options.document_split_criteria = DocumentSplitCriteria.HEADING_PARAGRAPH
save_options.document_split_heading_level = 2  # Split by Heading 2 only
doc.save("output.html", save_options)
```

**Split a Document by Sections**

You can split a document by section breaks using `SECTION_BREAK` as the `document_split_criteria` when saving to HTML:

```python
from aspose.words import Document, HtmlSaveOptions, DocumentSplitCriteria

doc = Document("input.docx")
save_options = HtmlSaveOptions()
save_options.document_split_criteria = DocumentSplitCriteria.SECTION_BREAK
doc.save("output.html", save_options)
```

Alternatively, manually split by sections for any output format:

```python
from aspose.words import Document

doc = Document("input.docx")
for i in range(doc.sections.count):
    new_doc = Document()
    new_doc.sections.add(doc.sections[i].clone())
    new_doc.save(f"section_{i + 1}.docx")
```

**Split by Pages**

Use the `Document.extract_pages(index, count)` method to extract specific pages (zero-based index). Supports all output formats.

**Page-by-page split:**

```python
from aspose.words import Document

doc = Document("input.docx")
for i in range(doc.page_count):
    sub_doc = doc.extract_pages(i, 1)
    sub_doc.save(f"page_{i + 1}.docx")
```

**Split by page ranges:**

```python
from aspose.words import Document

doc = Document("input.docx")
# Extract pages 2–4 (index 1 to 3)
sub_doc = doc.extract_pages(1, 3)
sub_doc.save("pages_2-4.docx")
```

> **Note:** Minor layout differences may occur due to rendering complexities.

**Callback Option to Save a Document**

When saving to HTML, use `document_part_saving_callback` to control naming or redirect output streams:

```python
from aspose.words import Document, HtmlSaveOptions

class CustomPartSavingCallback:
    def __init__(self):
        self.counter = 0

    def __call__(self, args):
        args.output_file_name = f"chapter_{self.counter}.html"
        self.counter += 1
        args.keep_output_stream_open = False

doc = Document("input.docx")
save_options = HtmlSaveOptions()
save_options.document_part_saving_callback = CustomPartSavingCallback()
doc.save("output.html", save_options)
```

> **Note:** Callbacks do not support stream redirection for EPUB.

**Merge the Split Document with Another Document**

After splitting, merge parts with other documents using `Document.append_document`:

```python
from aspose.words import Document, DocumentBuilder

# Load split parts
doc1 = Document("part1.docx")
doc2 = Document("part2.docx")

# Append doc2 to doc1
doc1.append_document(doc2)

# Save merged document
doc1.save("merged.docx")
```

---