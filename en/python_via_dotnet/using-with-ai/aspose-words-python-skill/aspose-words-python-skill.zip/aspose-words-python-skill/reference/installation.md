# Aspose.Words for Python – Installation
---
**URL:** https://docs.aspose.com/words/python-net/installation.md

**Contents:**
- System requirements and prerequisites
- Installation via pip
- Basic usage example

---
title: "Installation"
---

**System requirements and prerequisites**

Before installing Aspose.Words for Python via .NET, ensure your machine meets the [system requirements](/words/python-net/system-requirements/). The library is compatible with Python 3.8+ and runs on Windows, Linux, and macOS.

**Installation via pip**

The recommended method to install Aspose.Words for Python via .NET is using `pip`, the standard Python package manager. Run the following command in your terminal or command prompt:

```bash
pip install aspose-words
```

This command downloads and installs the latest stable version of the package from [PyPI](https://pypi.org/project/aspose-words/).

**Basic usage example**

After installation, import and use the library in your Python code:

```python
from aspose.words import Document

# Create a new document
doc = Document()
builder = DocumentBuilder(doc)

# Insert text
builder.writeln("Hello, Aspose.Words!")

# Save the document
doc.save("output.docx")
```

---