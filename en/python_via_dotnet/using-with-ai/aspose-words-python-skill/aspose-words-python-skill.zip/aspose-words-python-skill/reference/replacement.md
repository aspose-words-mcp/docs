# Aspose.Words for Python – Find and Replace

---
**URL:** https://docs.aspose.com/words/python-net/find-and-replace.md

**Contents:**
- Find and Replace Using Simple string replacement
- Find and Replace Using Regular expressions
- Find and Replace Using Metacharacters
- Find and Replace In Header and footer
- Ignore text during replacement
- Customizing replacement operations

---
title: "Find and Replace in Python"
---

**Find and Replace Using Simple string replacement**

Aspose.Words for Python via .NET supports simple string replacement using the `range.replace()` method. You can specify the search string, replacement string, case sensitivity, and whether to match only whole words.

```python
import aspose.words as aw

doc = aw.Document("input.docx")
doc.range.replace("CustomerName", "James Bond", aw.replacing.FindReplaceOptions())
doc.save("output.docx")
```

**Find and Replace Using Regular expressions**

Use `range.replace_regex()` to perform pattern-based replacements using regular expressions. Enable substitutions with `FindReplaceOptions.use_substitutions = True` to reference captured groups.

```python
import aspose.words as aw
import re

doc = aw.Document("input.docx")
options = aw.replacing.FindReplaceOptions()
options.use_substitutions = True
doc.range.replace_regex(r"([a-zA-Z]+) \1", r"$1", options)
doc.save("output.docx")
```

**Find and Replace Using Metacharacters**

Metacharacters allow inserting structural breaks in replacement text:
- `&p` – paragraph break  
- `&b` – section break  
- `&m` – page break  
- `&l` – line break  
- `&&` – literal `&`

```python
import aspose.words as aw

doc = aw.Document("input.docx")
doc.range.replace("PLACEHOLDER", "First line&pSecond line", aw.replacing.FindReplaceOptions())
doc.save("output.docx")
```

**Find and Replace In Header and footer**

Text in headers and footers can be replaced by accessing `HeaderFooter` nodes and calling `replace()` on their ranges.

```python
import aspose.words as aw

doc = aw.Document("input.docx")
for header_footer in doc.get_child_nodes(aw.NodeType.HEADER_FOOTER, True):
    header = header_footer.as_header_footer()
    header.range.replace("OldFooter", "NewFooter", aw.replacing.FindReplaceOptions())
doc.save("output.docx")
```

**Ignore text during replacement**

Use `FindReplaceOptions` to exclude specific document elements from replacement:
- `ignore_deleted` – skip deleted revisions  
- `ignore_inserted` – skip inserted revisions  
- `ignore_field_codes`, `ignore_fields`, `ignore_footnotes` – skip respective elements

```python
import aspose.words as aw

doc = aw.Document("input.docx")
options = aw.replacing.FindReplaceOptions()
options.ignore_deleted = True
doc.range.replace("placeholder", "real value", options)
doc.save("output.docx")
```

**Customizing replacement operations**

Advanced customization is possible via:
- `apply_font()` and `apply_paragraph_format()` – apply formatting to replacements  
- `use_substitutions` – enable regex group substitution  
- `IReplacingCallback` – implement custom logic during replacement

Example: highlight a specific word.

```python
import aspose.words as aw

doc = aw.Document("input.docx")
options = aw.replacing.FindReplaceOptions()
options.apply_font().highlight_color = aw.Color.yellow
doc.range.replace("important", "important", options)
doc.save("output.docx")
```

Example: replace text with HTML using `IReplacingCallback`.

```python
import aspose.words as aw
import aspose.words.replacing as aw_replace

class ReplaceWithHtmlHandler(aw_replace.IReplacingCallback):
    def replacing(self, args):
        # Insert HTML at match position
        builder = aw.DocumentBuilder(args.match.node.document)
        builder.move_to(args.match.node)
        builder.insert_html("<strong>REPLACED</strong>")
        return aw_replace.ReplaceAction.SKIP

doc = aw.Document("input.docx")
options = aw.replacing.FindReplaceOptions()
options.replacing_callback = ReplaceWithHtmlHandler()
doc.range.replace_regex(r"\[HTML\]", "", options)
doc.save("output.docx")
```

---