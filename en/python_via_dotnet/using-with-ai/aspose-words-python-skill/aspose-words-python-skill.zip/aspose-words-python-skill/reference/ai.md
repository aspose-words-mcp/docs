# Aspose.Words for Python - Use AI-powered Features

---
**URL:** https://docs.aspose.com/words/python-net/ai-powered-features.md

**Contents:**
- Supported AI Models
- Summarize a Document
- Translate a Document
- Grammar Checking

---
title: "AI-powered Features"
---

**Supported AI Models**

Aspose.Words for Python via .NET supports integration with generative language models from OpenAI, Google (Gemini), and Anthropic (Claude). These models enable document summarization, translation, and grammar checking.

You can create an `AiModel` instance using the static `create` method of the `AiModel` class and specify the model type via the `AiModelType` enumeration.

```python
model = aw.ai.AiModel.create(aw.ai.AiModelType.GPT_4O_MINI).with_api_key("API_KEY")
```

Supported model types include (but are not limited to):
- OpenAI: `GPT_4O`, `GPT_4O_MINI`, etc.
- Google: `GEMINI_FLASH_LATEST`, etc.
- Anthropic: `CLAUDE_3_5_SONNET`, etc.

The full list of supported models is available in the `AiModelType` enumeration.

**Summarize a Document**

Aspose.Words supports document summarization using AI models. You can summarize a single document or multiple documents and control the summary length.

Use the `summarize` method of the `AiModel` class. Configure summary length using `aw.ai.SummarizeOptions.summary_length`, which accepts:

- `VERY_SHORT` - generates 1-2 sentences
- `SHORT` - generates 3-4 sentences
- `MEDIUM` - generates 5-6 sentences
- `LONG` - generates 7-10 sentences
- `VERY_LONG` - generates 11-20 sentences

```python
first_doc = aw.Document(MY_DIR + "Big document.docx")
second_doc = aw.Document(MY_DIR + "Document.docx")
api_key = system_helper.environment.Environment.get_environment_variable("API_KEY")

model = aw.ai.AiModel.create(aw.ai.AiModelType.GPT_4O_MINI).with_api_key(api_key)

# Single document summary (short)
options = aw.ai.SummarizeOptions()
options.summary_length = aw.ai.SummaryLength.SHORT
one_document_summary = model.summarize(source_document=first_doc, options=options)
one_document_summary.save(ARTIFACTS_DIR + "AI.AiSummarize.One.docx")

# Multi-document summary (long)
options.summary_length = aw.ai.SummaryLength.LONG
multi_document_summary = model.summarize(source_documents=[first_doc, second_doc], options=options)
multi_document_summary.save(ARTIFACTS_DIR + "AI.AiSummarize.Multi.docx")
```

**Translate a Document**

Aspose.Words supports document translation using Google generative AI models. You can translate documents into over 300 languages defined in the `Language` enumeration.

Use the `translate` method of the `AiModel` class. If the source document contains multiple languages, the model attempts to detect and translate each segment individually.

```python
doc = aw.Document(file_name=MY_DIR + "Document.docx")
api_key = system_helper.environment.Environment.get_environment_variable("API_KEY")

model = aw.ai.AiModel.create(aw.ai.AiModelType.GEMINI_FLASH_LATEST).with_api_key(api_key)

translated_doc = model.translate(doc, aw.ai.Language.ARABIC)
translated_doc.save(file_name=ARTIFACTS_DIR + "AI.AiTranslate.docx")
```

**Grammar Checking**

Aspose.Words supports grammar checking using OpenAI, Google, and Claude models. The `check_grammar` method returns a new document with corrected grammar and optional stylistic improvements.

```python
doc = aw.Document(file_name=MY_DIR + 'Big document.docx')
api_key = system_helper.environment.Environment.get_environment_variable('API_KEY')

model = aw.ai.AiModel.create(aw.ai.AiModelType.GPT_4O_MINI).with_api_key(api_key)

grammar_options = aw.ai.CheckGrammarOptions()
grammar_options.improve_stylistics = True

proofed_doc = model.check_grammar(doc, grammar_options)
proofed_doc.save(file_name='AI.AiGrammar.docx')
```

---