# Aspose.Words for Python - Sign with Digital Signature

---
**URL:** https://docs.aspose.com/words/python-net/working-with-digital-signatures.md

**Contents:**
- Supported Formats
- Limitations of Digital Signatures
- Detect, Count, and Verify Digital Signatures
- Create a Digital Signature
  - Sign a Document
  - Add a Signature Line
  - Sign a Generated PDF Document
- Retrieve the Digital Signature Value
- Remove Digital Signatures

---
title: "Sign with Digital Signatures"
---

**Supported Formats**

Aspose.Words supports working with digital signatures on the following document formats:

- **Input formats**: DOC, OOXML (DOCX, DOCM, DOTX, DOTM), ODT
- **Output formats for signing**: PDF, XPS

**Limitations of Digital Signatures**

| Limitation | Alternative Option |
|------------|--------------------|
| Digital signatures are lost when a document is loaded and saved using Aspose.Words. | Detect signatures before processing and warn users if they will be removed. |
| Aspose.Words does not support signing macros. | Export to Word format and use Microsoft Word to sign macros. |

**Detect, Count, and Verify Digital Signatures**

Use `FileFormatUtil.detect_file_format()` to check if a document contains a digital signature via the `has_digital_signature` property. This only confirms presence, not validity.

To verify signatures and get their count, load them using `DigitalSignatureUtil.load_signatures()`, then inspect the `DigitalSignatureCollection`:

- `is_valid`: indicates whether all signatures are valid.
- `count`: returns the number of signatures.

```python
from aspose.words import Document, FileFormatUtil, DigitalSignatureUtil

# Detect presence of digital signatures
info = FileFormatUtil.detect_file_format("document.docx")
has_sig = info.has_digital_signature

# Load and verify signatures
signatures = DigitalSignatureUtil.load_signatures("document.docx")
print(f"Total signatures: {signatures.count}")
print(f"All valid: {signatures.is_valid}")
```

**Create a Digital Signature**

To sign a document, you need a certificate (X.509). Use `CertificateHolder.create()` to load or create a certificate, then apply it using `DigitalSignatureUtil.sign()`.

**Sign a Document**

Use `DigitalSignatureUtil.sign()` with a `CertificateHolder` and `SignOptions`:

```python
from aspose.words import DigitalSignatureUtil, CertificateHolder, SignOptions

cert_holder = CertificateHolder.create("mycert.pfx", "password")
sign_options = SignOptions()
sign_options.sign_time = "2024-01-01"

DigitalSignatureUtil.sign("input.docx", "signed.docx", cert_holder, sign_options)
```

**Add a Signature Line**

A signature line is a visual placeholder in the document. Insert it using `DocumentBuilder.insert_signature_line()` and configure with `SignatureLineOptions`.

```python
from aspose.words import Document, DocumentBuilder, SignatureLineOptions

doc = Document()
builder = DocumentBuilder(doc)

options = SignatureLineOptions()
options.signer = "John Doe"
options.signer_title = "Manager"
options.show_date = True

builder.insert_signature_line(options)
doc.save("document_with_signature_line.docx")
```

**Sign a Generated PDF Document**

When saving to PDF, use `PdfDigitalSignatureDetails` to apply a digital signature:

```python
from aspose.words import Document, PdfSaveOptions, CertificateHolder, PdfDigitalSignatureDetails

doc = Document("input.docx")
cert_holder = CertificateHolder.create("mycert.pfx", "password")

signature_details = PdfDigitalSignatureDetails()
signature_details.certificate_holder = cert_holder
signature_details.reason = "Document approval"
signature_details.location = "New York"

save_options = PdfSaveOptions()
save_options.digital_signature_details = signature_details

doc.save("signed.pdf", save_options)
```

**Retrieve the Digital Signature Value**

Extract the raw signature value (as a byte array) from a `DigitalSignature` object:

```python
from aspose.words import DigitalSignatureUtil

signatures = DigitalSignatureUtil.load_signatures("signed.docx")
for sig in signatures:
    signature_value = sig.signature_value  # bytes
    print(f"Signature length: {len(signature_value)} bytes")
```

**Remove Digital Signatures**

Remove *all* digital signatures from a document using `DigitalSignatureUtil.remove_all_signatures()`:

```python
from aspose.words import DigitalSignatureUtil

DigitalSignatureUtil.remove_all_signatures("signed.docx", "unsigned.docx")
```

> **Note**: It is not possible to remove only one signature from a document with multiple signatures.

---