# Aspose.Words for Python - Conversion

---
**URL:** https://docs.aspose.com/words/python-net/convert-a-document/

**Contents:**
- Overview of Document Conversion
- Convert to PDF
- Convert to Image
- Convert to Excel (XLSX)
- Convert to HTML, MHTML, or EPUB
- Convert PDF to Other Formats
- Convert Multi-page Documents to Images

---
title: "Convert a Document"
---

**Overview of Document Conversion**

Document conversion in Aspose.Words for Python via .NET is performed by loading a document into a `Document` object and saving it in the desired format using one of the `save()` methods. The library supports conversion between any combination of its supported load and save formats.

Basic conversion requires two steps:
1. Load the document: `doc = aw.Document("input.docx")`
2. Save in target format: `doc.save("output.pdf")`

The load format is inferred from the file extension or explicitly specified via `LoadFormat`. The save format is determined by the output file extension or explicitly set via `SaveFormat`.

Below are examples of popular conversions.

**Convert to PDF**

Documents in any supported format (DOC, DOCX, RTF, HTML, images, etc.) can be converted to PDF. PDF conversion involves layout calculation to preserve formatting and pagination.

```python
import aspose.words as aw

doc = aw.Document("input.docx")
doc.save("output.pdf")
```

To specify PDF compliance (e.g., PDF/A, PDF/UA, PDF 1.7), use `PdfSaveOptions`:

```python
options = aw.saving.PdfSaveOptions()
options.compliance = aw.saving.PdfCompliance.PDF17
doc.save("output.pdf", options)
```

To reduce output size, enable optimization:

```python
options = aw.saving.PdfSaveOptions()
options.optimize_output = True
doc.save("output.pdf", options)
```

Images (single-page or multi-page TIFF/GIF) can also be converted to PDF:

```python
doc = aw.Document("image.jpg")
doc.save("image.pdf")
```

**Convert to Image**

Documents can be converted to raster image formats: JPEG, PNG, BMP, GIF, TIFF, WebP.

Basic conversion:

```python
doc = aw.Document("input.docx")
doc.save("output.jpg", aw.SaveFormat.JPEG)
```

Use `ImageSaveOptions` to control resolution, quality, page range, pixel format, and color settings:

```python
options = aw.saving.ImageSaveOptions(aw.SaveFormat.PNG)
options.horizontal_resolution = 300
options.vertical_resolution = 300
options.page_set = aw.saving.PageSet([0])  # first page only
doc.save("preview.png", options)
```

**Convert to Excel (XLSX)**

Documents in any supported format can be saved as XLSX using `XlsxSaveOptions`.

```python
doc = aw.Document("input.pdf")
doc.save("output.xlsx", aw.SaveFormat.XLSX)
```

Compression level can be adjusted:

```python
options = aw.saving.XlsxSaveOptions()
options.compression_level = aw.saving.CompressionLevel.MAXIMUM
doc.save("compressed.xlsx", options)
```

Find-and-replace can be performed before saving:

```python
doc.range.replace("old", "new", aw.FindReplaceOptions())
doc.save("output.xlsx", aw.SaveFormat.XLSX)
```

**Convert to HTML, MHTML, or EPUB**

Documents can be converted to HTML, MHTML, or EPUB using the `save()` method with appropriate `SaveFormat`.

```python
doc = aw.Document("input.docx")
doc.save("output.html", aw.SaveFormat.HTML)
```

Use `HtmlSaveOptions` to configure resource handling, font embedding, and round-trip information.

Export resources to a folder:

```python
options = aw.saving.HtmlSaveOptions()
options.resource_folder = "resources"
options.resource_folder_alias = "res"
doc.save("output.html", options)
```

**Convert PDF to Other Formats**

PDF files can be loaded and converted to Word, image, or other formats.

```python
doc = aw.Document("input.pdf")
doc.save("output.docx", aw.SaveFormat.DOCX)
```

Use `PdfLoadOptions` to control page range, skip images, or provide a password:

```python
options = aw.loading.PdfLoadOptions()
options.page_index = 0
options.page_count = 3
options.skip_pdf_images = True
doc = aw.Document("input.pdf", options)
doc.save("output.docx")
```

Password-protected PDFs require the password:

```python
options = aw.loading.PdfLoadOptions()
options.password = "secret"
doc = aw.Document("protected.pdf", options)
doc.save("unlocked.docx")
```

Supported PDF content includes text, images, tables, lists, headers/footers, footnotes, and page numbers.

**Convert Multi-page Documents to Images**

Multi-page documents can be exported to a single image using `MultiPageLayout`.

```python
options = aw.saving.ImageSaveOptions(aw.SaveFormat.JPEG)
options.page_layout = aw.saving.MultiPageLayout.horizontal(10.0)
doc.save("output.jpg", options)
```

Layout options:
- `single_page`: first page only
- `grid(columns, spacing)`: matrix layout
- `horizontal(spacing)`: side-by-side
- `vertical(spacing)`: stacked vertically
- `tiff_frames()`: multi-frame TIFF

Customize appearance:

```python
layout = aw.saving.MultiPageLayout.grid(3, 5.0, 5.0)
layout.back_color = aspose.pydrawing.Color.white
layout.border_color = aspose.pydrawing.Color.black
layout.border_width = 1
options.page_layout = layout
```

---