# Aspose.Words for Python - Watermark

---
**URL:** https://docs.aspose.com/words/python-net/working-with-watermark.md

**Contents:**
- Add a Watermark to a Document
- Remove Watermark from a Document
- Add a Watermark into a Table Cell

---
title: "Working with Watermark"
---

**Add a Watermark to a Document**

Aspose.Words for Python via .NET provides the `Watermark` class and `WatermarkType` enumeration to add text, image, or no watermark to a document.

**Add Text Watermark**

Use `TextWatermarkOptions` to configure font, size, color, and other properties, then apply via `Watermark.set_text()`:

```python
import aspose.pydrawing
import aspose.words as aw

doc = aw.Document("input.docx")
options = aw.TextWatermarkOptions()
options.font_family = "Arial"
options.font_size = 72
options.color = aspose.pydrawing.Color.gray
options.layout = aw.TextWatermarkLayout.DIAGONAL
doc.watermark.set_text("CONFIDENTIAL", options)
doc.save("output.docx")
```

**Add Image Watermark**

Use `ImageWatermarkOptions` to configure scaling and layout, then apply via `Watermark.set_image()` with a file path, stream, or bytes:

```python
import aspose.words as aw

doc = aw.Document("input.docx")
options = aw.ImageWatermarkOptions()
options.scale = 0.5
doc.watermark.set_image("logo.png", options)
doc.save("output.docx")
```

---

**Remove Watermark from a Document**

To remove a watermark added via the `Watermark` API, call `Watermark.remove()`:

```python
import aspose.words as aw

doc = aw.Document("watermarked.docx")
doc.watermark.remove()
doc.save("clean.docx")
```

If the watermark was added as a `Shape`, assign a unique name when creating it, then locate and remove it by name:

```python
import aspose.words as aw

doc = aw.Document("input.docx")
# When adding:
shape = aw.drawing.Shape(doc, aw.drawing.ShapeType.TEXT_PLAIN_TEXT)
shape.name = "MyWatermark"
# ... configure and insert ...

# Later, to remove:
for node in doc.get_child_nodes(aw.NodeType.SHAPE, True):
    if node.as_shape().name == "MyWatermark":
        node.remove()
        break
doc.save("output.docx")
```

---