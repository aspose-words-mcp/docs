# Aspose.Words for Python - Create or Load a Document

---
**URL:** https://docs.aspose.com/words/python-net/create-or-load-a-document.md

**Contents:**
- Create a New Document
- Load a Document
  - Load from a File
  - Load from a Stream
- Detect File Format When Loading
- Specify Load Options
  - Set Microsoft Word Version to Change the Appearance
  - Set Language Preferences to Change the Appearance
  - Use WarningCallback to Control Problems While Loading a Document
  - Use ResourceLoadingCallback to Control the External Resources Loading
  - Use TempFolder to Avoid a Memory Exception
  - Set the Encoding Explicitly
  - Load Encrypted Documents

---
title: "Create or Load a Document"
---

**Create a New Document**

Use the `Document` constructor without parameters to create a blank document. For programmatic document generation, use the `DocumentBuilder` class.

```python
import aspose.words as aw

doc = aw.Document()
builder = aw.DocumentBuilder(doc)
builder.writeln("Hello World!")
doc.save("output.docx")
```

A new blank document contains one section with default parameters, one empty paragraph, and built-in styles—equivalent to a “New document” in Microsoft Word. Default paper size is `PaperSize.LETTER`.

**Load a Document**

Load an existing document using one of the `Document` constructors, passing either a file path or a stream. The format is auto-detected from the file extension.

**Load from a File**

```python
doc = aw.Document("input.docx")
```

**Load from a Stream**

```python
import io

stream = io.FileIO("input.docx")
doc = aw.Document(stream)
stream.close()
```

**Detect File Format When Loading**

Use `FileFormatUtil.detect_file_format()` to determine the format of a file without loading it. Returns a `FileFormatInfo` object with format type and metadata (e.g., encrypted, signed, macros).

```python
from aspose.words import FileFormatUtil

info = FileFormatUtil.detect_file_format("input.docx")
load_format = info.load_format  # e.g., LoadFormat.DOCX
is_encrypted = info.is_encrypted
has_macros = info.has_macros
```

Note: This method only checks format signature bytes and does not guarantee successful loading.

**Set Microsoft Word Version to Change the Appearance**

Set `LoadOptions.msw_version` to emulate rendering behavior of a specific Microsoft Word version.

```python
import aspose.words as aw
from aspose.words import settings

load_options = aw.loading.LoadOptions()
load_options.msw_version = settings.MsWordVersion.WORD2010
doc = aw.Document("input.docx", load_options)
```

**Set Language Preferences to Change the Appearance**

Use `LoadOptions.language_preferences` to set editing language(s), affecting rendering and layout.

```python
import aspose.words as aw

load_options = aw.loading.LoadOptions()
load_options.language_preferences.add_editing_language(aw.loading.EditingLanguage.JAPANESE)
doc = aw.Document("input.docx", load_options)
```

**Use WarningCallback to Control Problems While Loading a Document**

Implement `IWarningCallback` to capture warnings during document loading (e.g., unsupported features, malformed content).

```python
import aspose.words as aw

class MyWarningCallback(aw.IWarningCallback):
    def warning(self, args):
        print(f"Warning: {args.description}")

load_options = aw.loading.LoadOptions()
load_options.warning_callback = MyWarningCallback()
doc = aw.Document("input.docx", load_options)
```

**Use ResourceLoadingCallback to Control the External Resources Loading**

Implement `IResourceLoadingCallback` to control how external resources (e.g., images) are loaded.

```python
import aspose.words as aw

class MyResourceLoadingCallback(aw.loading.IResourceLoadingCallback):
    def resource_loading(self, args):
        # Example: skip loading external images
        if args.resource_type == aw.loading.ResourceType.IMAGE:
            return aw.loading.ResourceLoadingAction.USER_PROVIDED
        return aw.loading.ResourceLoadingAction.DEFAULT

load_options = aw.loading.LoadOptions()
load_options.resource_loading_callback = MyResourceLoadingCallback()
doc = aw.Document("input.docx", load_options)
```

**Use TempFolder to Avoid a Memory Exception**

For large documents, use `LoadOptions.temp_folder` to offload temporary data to disk.

```python
import aspose.words as aw

load_options = aw.loading.LoadOptions()
load_options.temp_folder = "C:/temp/aw_temp"
doc = aw.Document("large.docx", load_options)
```

**Set the Encoding Explicitly**

Override auto-detected encoding using `LoadOptions.encoding`.

```python
import aspose.words as aw

load_options = aw.loading.LoadOptions()
load_options.encoding = "windows-1251"
doc = aw.Document("legacy.txt", load_options)
```

**Load Encrypted Documents**

Load password-protected documents using `LoadOptions.password`.

```python
import aspose.words as aw

load_options = aw.loading.LoadOptions()
load_options.password = "MySecret"
doc = aw.Document("encrypted.docx", load_options)
```

To detect encryption before loading:

```python
from aspose.words import FileFormatUtil

info = FileFormatUtil.detect_file_format("input.docx")
if info.is_encrypted:
    # Prompt for password or skip
    pass
```

---